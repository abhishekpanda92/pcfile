package com.virtusa.databaseservices;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcBasics {
	

	public static void main(String[] args) throws SQLException {
		
		for(int j = 0;j<4;j++)
		{
		for(int i = 0 ;i<5; i++)
		{
			if(5>2)
			{
				if(7>5)
				{
					System.out.println("yffffas");
					break;
				}
				
				
			}
		}
		System.out.println("yeas");
		}
//		Driver driver = new oracle.jdbc.OracleDriver();
//		DriverManager.registerDriver(driver);
//		System.out.println("Driver loaded...");
//
////		Connection connection = DriverManager.getConnection(
////				"jdbc:oracle:thin:@10.7.80.61:1521:xe", "hr", "hr"); // url like
//			
//		Connection connection = DriverManager.getConnection(
//				"jdbc:oracle:thin:@localhost:1521:xe", "system", "system");// http
//		System.out.println("Connection established...");															// smtp
//		Statement statement = connection.createStatement(); // connection and
//
//		statement.executeUpdate("insert into DEPARTMENT values(25,'Development','Hyderabad')");
//		
//		String sql = ("SELECT * FROM DEPARTMENT");
//		ResultSet rs = statement.executeQuery(sql); //ResultSet is an interface
//		
//		
//		while(rs.next()) { 
//		 int departmentId = rs.getInt(1); 
//		 String departmentName = rs.getString(2);
//		 String departmentLocation = rs.getString(3);
//		 
//		 System.out.println(departmentId +" "+departmentName + " "+departmentLocation);
//		}

		
		//prepared statements pre-compiled sql statements
	}
}
