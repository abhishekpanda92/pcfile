package com.virtusa.testsuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.virtusa.bankapptest.BankAccountValidationTest;
import com.virtusa.bankapptest.BankingDepositTest;
import com.virtusa.bankapptest.BankingWithdrawalTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({ BankingWithdrawalTest.class,BankingDepositTest.class,BankAccountValidationTest.class})
public class TestSuite {
}