package com.virtusa.bankapptest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.virtusa.bankingservices.AccountOperations;
import com.virtusa.userdefinedexceptions.InsufficientBalanceException;
import com.virtusa.userdefinedexceptions.InvalidAccountNumberException;
import com.virtusa.userdefinedexceptions.InvalidAmountException;

public class BankingDepositTest {

	private AccountOperations accountOperations;

	@Before
	public void beforeMethod() {
		accountOperations = new AccountOperations();
		System.out.println("Account Operations object created...");

	}
	
	@After
	public void afterMethod() {
		accountOperations = null;
	}

	@Test
	public void TestDeposit() throws InsufficientBalanceException, InvalidAmountException, InvalidAccountNumberException {
		int amount = accountOperations.balanceEnquiryOperation(1001);
		accountOperations.depositMoneyOperation(1001, amount);
		assertEquals(amount+amount, accountOperations.balanceEnquiryOperation(1001));
	}
	
	@Test(expected = InvalidAmountException.class)
	public void TestInvalidAmountDeposit() throws InsufficientBalanceException, InvalidAmountException, InvalidAccountNumberException {
		int amount = -100;
		accountOperations.depositMoneyOperation(1001, amount);
		assertEquals(amount+amount, accountOperations.balanceEnquiryOperation(1001));
	}

}
