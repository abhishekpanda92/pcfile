package com.virtusa.bankapptest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.virtusa.bankingservices.AccountOperations;
import com.virtusa.userdefinedexceptions.InsufficientBalanceException;
import com.virtusa.userdefinedexceptions.InvalidAccountNumberException;
import com.virtusa.userdefinedexceptions.InvalidAmountException;

public class BankAccountValidationTest {

	private AccountOperations accountOperations;

	@Before
	public void beforeMethod() {
		accountOperations = new AccountOperations();
		System.out.println("Account Operations object created...");

	}

	@After
	public void afterMethod() {
		accountOperations = null;
	}

	@Test(expected = InvalidAccountNumberException.class)
	public void TestInvalidAccountBalanceCheck() throws InvalidAmountException,
			InvalidAccountNumberException {
		int amount = accountOperations.balanceEnquiryOperation(20000);
		// accountOperations.depositMoneyOperation(1001, amount);
	}

	@Test(expected = InvalidAccountNumberException.class)
	public void TestInvalidAccountAmountDeposit()
			throws InvalidAmountException, InvalidAccountNumberException {
		int amount = accountOperations.balanceEnquiryOperation(20000);
		accountOperations.depositMoneyOperation(1001, amount);
	}

	@Test(expected = InvalidAccountNumberException.class)
	public void TestInvalidAccountAmountWithdraw()
			throws InvalidAmountException, InvalidAccountNumberException, InsufficientBalanceException {
		int amount = accountOperations.balanceEnquiryOperation(20000);
		accountOperations.withdrawMoneyOperation(1001, amount);
	}

}
