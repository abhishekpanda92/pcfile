package com.virtusa.bankapptest;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.virtusa.bankingservices.AccountOperations;
import com.virtusa.bankingservices.AccountServices;
import com.virtusa.userdefinedexceptions.InsufficientBalanceException;
import com.virtusa.userdefinedexceptions.InvalidAccountNumberException;
import com.virtusa.userdefinedexceptions.InvalidAmountException;

public class BankingWithdrawalTest {

	private AccountOperations accountOperations;

	@Before
	public void beforeMethod() {
		accountOperations = new AccountOperations();
		System.out.println("Account Operations object created...");
	}

	@After
	public void afterMethod() {
		accountOperations = null;
		// System.out.println("Account Operations object created...");

	}

	@Test
	public void TestWithdrawal() throws InsufficientBalanceException,
			InvalidAmountException, InvalidAccountNumberException {
		int amount = accountOperations.balanceEnquiryOperation(1001);
		accountOperations.withdrawMoneyOperation(1001, amount);
		assertEquals(0, accountOperations.balanceEnquiryOperation(1001));
	}

	@Test(expected = InsufficientBalanceException.class)
	// to check exceptions
	public void TestInvalidAmountWithdrawal()
			throws InsufficientBalanceException, InvalidAmountException,
			InvalidAccountNumberException {
		AccountOperations accountOperations = new AccountOperations();
		int amount = accountOperations.balanceEnquiryOperation(1001);
		accountOperations.withdrawMoneyOperation(1001, amount + amount);
	}

	@Test(expected = InvalidAmountException.class)
	public void TestNegativeAmountWithdrawal()
			throws InsufficientBalanceException, InvalidAmountException,
			InvalidAccountNumberException {
		AccountOperations accountOperations = new AccountOperations();
		int amount = -100;
		accountOperations.withdrawMoneyOperation(1001, amount);
	}

}
