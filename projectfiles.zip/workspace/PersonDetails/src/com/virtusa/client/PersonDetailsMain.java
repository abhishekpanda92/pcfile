package com.virtusa.client;

import java.util.Scanner;

import com.virtusa.model.Person;
import com.virtusa.services.PersonDetailsServices;

public class PersonDetailsMain {

	public static void main(String[] args) {
		final PersonDetailsServices personDetailsServices = new PersonDetailsServices();

		Thread add = new Thread(new Runnable() {

			@Override
			public void run() {
				int condition = 4;
				while (condition > 0) {
					condition--;
					// TODO Auto-generated method stub
					System.out.println("Enter your name");
					Scanner scanner = new Scanner(System.in);
					String name = scanner.nextLine();
					System.out.println("Enter your age");
					int age = scanner.nextInt();
					Person person = new Person(name, age);
					personDetailsServices.addPerson(person);
				}
			}

		});

		Thread display = new Thread(new Runnable() {

			@Override
			public void run() {
				
				System.out.println("Inside display thread...");
				personDetailsServices.display();
					
			}

		});
		
		
	
		add.start();
		try {
			add.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		display.start();


	}
}
