package com.virtusa.services;

import java.util.ArrayList;
import java.util.List;

import com.virtusa.model.Person;

public class PersonDetailsServices {
	private List<Person> personList = new ArrayList<>();
	
	public void  addPerson(Person person)
	{
		personList.add(person);
	}
	
	public void  display()
	{
		for(int i = 0 ;i<personList.size();i++ )
		{
			if(personList.get(i).getAge() <= 10)
			{
				personList.remove(i);
				i--;
			}
			else
			{
				System.out.println(personList.get(i));
			}
		}
	}
	
	
}
