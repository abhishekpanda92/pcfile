package com.virtusa.services;

import java.sql.SQLException;
import java.util.ArrayList;

import com.virtusa.model.Employee;
import com.virtusa.userdefinedexceptions.AlreadyExistingEmployeeNumberException;
import com.virtusa.userdefinedexceptions.InvalidEmployeeIDException;

public interface EmployeeDao {
	/**
	 * 
	 * @param employee
	 * @return
	 * @throws AlreadyExistingEmployeeNumberException
	 * @throws SQLException
	 */
	 int insertEmployee(Employee employee)
			throws AlreadyExistingEmployeeNumberException,SQLException;

	/**
	 * 
	 * @param empId
	 * @return
	 * @throws InvalidEmployeeIDException
	 */
	int removeEmployee(int empId) throws InvalidEmployeeIDException;

	/**
	 * 
	 * @param empName
	 * @return
	 * @throws InvalidEmployeeIDException
	 */
	 Employee fetchEmployee(String empName)
			throws InvalidEmployeeIDException;

	/**
	 * 
	 * @return
	 */
	 ArrayList<Integer> fetchEmployeeIds();
}
