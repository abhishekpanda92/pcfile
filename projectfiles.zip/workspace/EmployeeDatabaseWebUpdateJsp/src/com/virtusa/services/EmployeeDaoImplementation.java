package com.virtusa.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibernate.connection.HibernateSessionFactory;
import com.virtusa.model.Employee;
import com.virtusa.userdefinedexceptions.AlreadyExistingEmployeeNumberException;
import com.virtusa.userdefinedexceptions.InvalidEmployeeIDException;

public class EmployeeDaoImplementation implements EmployeeDao {


	/**
	 * throws AlreadyExistingEmployeeNumberException inserts an employee to the
	 * database
	 */
	@Override
	public int insertEmployee(Employee employee)
			throws AlreadyExistingEmployeeNumberException,SQLException {
		// TODO Auto-generated method stub
		if (fetchEmployee(employee.getEmployeeName()) != null)
			throw new AlreadyExistingEmployeeNumberException(
					employee.getEmployeeCode());
		Session session = HibernateSessionFactory.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		session.save(employee);
		tx.commit();
		session.close();
		return 1;
	}

	/**
	 * fetches an employee based on the name
	 */
	public Employee fetchEmployee(String name) {
		// TODO Auto-generated method stub
		Employee employee = null;
		Session session = HibernateSessionFactory.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		employee = (Employee) session.get(Employee.class, name);
		tx.commit();
		session.close();
		return employee;
	}

	/**
	 * throws InvalidEmployeeIDException removes an Employee from database
	 * through id of the employee
	 */
	@Override
	public int removeEmployee(int empId) throws InvalidEmployeeIDException {
		// TODO Auto-generated method stub
		Employee employee = null;
		String sql = "select emp from Employee as emp where emp.employeeCode = "
				+ empId;
		Session session = HibernateSessionFactory.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery(sql);
		employee = (Employee) query.uniqueResult();
		System.out.println(employee);
		session.delete(employee);
		tx.commit();
		session.close();
		return 0;
	}

	/**
	 * fetches the list of EmployeeIds
	 */
	@Override
	public ArrayList<Integer> fetchEmployeeIds() {
		// TODO Auto-generated method stub
		String sql = "select emp.employeeCode from Employee as emp";
		Session session = HibernateSessionFactory.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery(sql);
		List<Integer> idList = query.list();
		tx.commit();
		session.close();
		return (ArrayList<Integer>) idList;
	}

	/**
	 * updates the password of an employee
	 * 
	 * @param password
	 * @param empId
	 * @return
	 */
	public int updatePassword(String password, int empId) {
		Employee employee = null;
		String sql = "select emp from Employee as emp where emp.employeeCode = "
				+ empId;
		Session session = HibernateSessionFactory.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery(sql);
		employee = (Employee) query.uniqueResult();
		employee.setPassword(password);
		session.update(employee);
		tx.commit();
		session.close();
		return 0;
	}

	/**
	 * updates the salary of an employee
	 * 
	 * @param salary
	 * @param empId
	 * @return
	 */
	public int updateSalary(double salary, int empId) {
		Employee employee = null;
		String sql = "select emp from Employee as emp where emp.employeeCode = "
				+ empId;
		Session session = HibernateSessionFactory.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery(sql);
		employee = (Employee) query.uniqueResult();
		employee.setEmployeeSalary(salary);
		session.update(employee);
		tx.commit();
		session.close();
		return 0;
	}

	/**
	 * updates the department of an employee
	 * 
	 * @param dept
	 * @param empId
	 * @return
	 */
	public int updateEmpDept(int dept, int empId) {
		Employee employee = null;
		String sql = "select emp from Employee as emp where emp.employeeCode = "
				+ empId;
		Session session = HibernateSessionFactory.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery(sql);
		employee = (Employee) query.uniqueResult();
		employee.setDepartmentId(dept);
		session.update(employee);
		tx.commit();
		session.close();
		return 0;
	}

	/**
	 * fetches details of all the employees
	 * 
	 * @return
	 */
	public List<Employee> getEmployees() {
		List<Employee> employeeList;
		String sql = ("SELECT emp FROM Employee as emp");
		Session session = HibernateSessionFactory.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery(sql);
		employeeList = query.list();
		tx.commit();
		session.close();
		return employeeList;
	}

	public List<Employee> getEmployeeList(String name) {
		List<Employee> employeeList;
		String sql = ("SELECT emp FROM Employee as emp  where employeeName like \'"
				+ name + "%\'");
		Session session = HibernateSessionFactory.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery(sql);
		employeeList = query.list();
		tx.commit();
		session.close();
		return employeeList;
	}

}
