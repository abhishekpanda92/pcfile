package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.model.Employee;
import com.virtusa.services.EmployeeDaoImplementation;
import com.virtusa.userdefinedexceptions.AlreadyExistingEmployeeNumberException;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeDatabase")
public class EmployeeAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		try {
			int empCode = Integer.parseInt(request.getParameter("empcode"));
			String empName = request.getParameter("empname");
			double empSalary = Double.parseDouble(request
					.getParameter("empsalary"));
			String empPassword = request.getParameter("emppassword");
			int deptId = Integer.parseInt(request.getParameter("DepartmentId"));
			Employee employee = new Employee(empCode, empPassword, empName,
					empSalary, deptId);
			EmployeeDaoImplementation employeeDaoImplementation = new EmployeeDaoImplementation();
			try {
				employeeDaoImplementation.insertEmployee(employee);
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Employee Database</title>");
				out.println("</head>");
				out.println("<body>");
				out.println("Employee added to the database");
				out.println("</body>");
				out.println("</html>");
				RequestDispatcher rd = request
						.getRequestDispatcher("HrHomePage.jsp");
				rd.include(request, response);
			} catch (AlreadyExistingEmployeeNumberException e) {
				// TODO Auto-generated catch block
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Employee Database</title>");
				out.println("</head>");
				out.println("<body>");
				out.println("<h2> The Employee already Exists </h2>");
				out.println("</body>");
				out.println("</html>");
				RequestDispatcher rd = request
						.getRequestDispatcher("HrHomePage.jsp");
				rd.include(request, response);
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Employee Database</title>");
				out.println("</head>");
				out.println("<body>");
				out.println("<h2> Kindly fill all the boxes... All the fields are mandatory</h2>");
				out.println("</body>");
				out.println("</html>");
				RequestDispatcher rd = request
						.getRequestDispatcher("HrHomePage.jsp");
				rd.include(request, response);
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Employee Database</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h2>Enter Integer value for employeeCode and double value for salary</h2>");
			out.println("</body>");
			out.println("</html>");
			RequestDispatcher rd = request
					.getRequestDispatcher("HrHomePage.jsp");
			rd.include(request, response);
		}
		
	}
}
