package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.services.EmployeeDaoImplementation;

/**
 * Servlet implementation class UpdateEmployeeInfo
 */
@WebServlet("/UpdateEmployeeInfo")
public class UpdateEmployeeInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	EmployeeDaoImplementation employeeDaoImplementation = new EmployeeDaoImplementation();

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		boolean status = false;
		response.setContentType("text/html");
		int id = Integer.parseInt(request.getParameter("cat"));

		String getPassword = request.getParameter("emppassword");
		if (getPassword.length() > 0) {
			employeeDaoImplementation.updatePassword(getPassword, id);
			status = true;
		}
		
		String empSalary = request.getParameter("empsalary");
		if (empSalary.length() > 0) {
			double salary = Double.parseDouble(empSalary);
			employeeDaoImplementation.updateSalary(salary, id);
			status = true;
		}
		
		String getDept = request.getParameter("empdeptid");
		if (getDept.length() > 0) {
			int dept = Integer.parseInt(getDept);
			employeeDaoImplementation.updateEmpDept(dept, id);
			status = true;
		}
		if (status) {
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Employee Updation</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("Employee data updated to the database");
			out.println("</body>");
			out.println("</html>");
			RequestDispatcher rd = request
					.getRequestDispatcher("UpdateEmployee.jsp");
			rd.include(request, response);
		} else {
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Employee Updation</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("Updation unsuccessful...Do not leave all the fieldsEmpty");
			out.println("</body>");
			out.println("</html>");
			RequestDispatcher rd = request
					.getRequestDispatcher("UpdateEmployee.jsp");
			rd.include(request, response);
		}
	}
}
