package com.virtusa.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.model.Employee;
import com.virtusa.services.EmployeeDaoImplementation;

/**
 * Servlet implementation class AllEmployeesServlet
 */
@WebServlet("/AllEmployeesServlet")
public class AllEmployeesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		EmployeeDaoImplementation employeeDaoImplementation = new EmployeeDaoImplementation();
		List<Employee> employeeList = employeeDaoImplementation.getEmployees();
		request.setAttribute("empList", employeeList);
		RequestDispatcher rd = request
				.getRequestDispatcher("EmployeeDetails.jsp");
		rd.forward(request, response);
	}
}
