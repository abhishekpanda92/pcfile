package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.model.Employee;
import com.virtusa.services.EmployeeDaoImplementation;

/**
 * Servlet implementation class ServletBasics
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String userName = request.getParameter("uname");
		String password = request.getParameter("password");
		EmployeeDaoImplementation employeeDaoImplementation = new EmployeeDaoImplementation();
		HttpSession session = request.getSession();
		session.setAttribute("user", userName); // vALUES can be any java object
		Employee employee = employeeDaoImplementation.fetchEmployee(userName);
		if (employee != null && employee.getPassword().equals(password)
				&& employee.getDepartmentId() == 1) {
			response.sendRedirect("HrHomePage.jsp");
		} else {
			PrintWriter out = response.getWriter();
			out.println("You are not authorized!!!!..........Invalid Credentials");
			RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			rd.include(request, response);
		}
	}
}
