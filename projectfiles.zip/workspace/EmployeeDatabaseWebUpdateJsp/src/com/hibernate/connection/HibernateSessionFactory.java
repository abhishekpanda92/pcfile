package com.hibernate.connection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateSessionFactory {
	private static Configuration cfg = new Configuration();
	private static SessionFactory factory;
    private static FileInputStream fIn ;
	private static Properties prop = null;
	static {
		try {
			fIn = new FileInputStream(
					"C:\\Users\\abhishekpa@virtusa.com\\workspace\\EmployeeDatabaseWebUpdateJsp\\src\\com\\hibernate\\connection\\hibernateroperties.properties");
			prop = new Properties();
			prop.load(fIn);
			cfg.configure(prop.getProperty("configxml"));
			factory = cfg.buildSessionFactory();			
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally{
			try {
				fIn.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * This method returns a SessionFactory object which can be used by all the
	 * calling methods
	 * 
	 * @return
	 */
	public static SessionFactory getSessionFactory() {
		return factory;
	}
}
