function validateForm() {
    var x = document.forms["myForm"]["uname"].value;
    var y = document.forms["myForm"]["password"].value;
    if ((x == null || x == "") || (y == null || y == "") ) {
        alert("Name and Password must be filled out");
        return false;
    }
}
