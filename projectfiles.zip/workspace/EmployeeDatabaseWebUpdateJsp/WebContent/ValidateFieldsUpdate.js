function validateForm() {
    var x = document.forms["myForm"]["empcode"].value;
    var y = document.forms["myForm"]["empname"].value;
    if ((x == null || x == "") || (y == null || y == "") ) {
        alert("All details must be filled out");
        return false;
    }
}
