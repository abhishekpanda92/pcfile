package com.virtusa.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import com.virtusa.model.Resource;


public class CollectionServices {
	List<Resource> resources = new ArrayList<>();
	SimpleDateFormat simpleFormat = new SimpleDateFormat("dd/mm/yyyy");
	
	public void addResource(Resource resource)
	{
		resources.add(resource);
	}
	
	public void removeResource(int userId)
	{
		Iterator<Resource> iterator = resources.iterator();
		while (iterator.hasNext()) {
			Resource resource = iterator.next();
			if(resource.getUserId() == userId)
			{
				resources.remove(resource);
				return;
			}
			//System.out.println("No such resource found");
		}
	}
	
	public void displayDetails() {
		Collections.sort(resources);
		Iterator<Resource> iterator = resources.iterator();
		while (iterator.hasNext()) {
			Resource resource = iterator.next();
			System.out.println(resource);
		}
	}
}
