package com.virtusa.services;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.virtusa.model.Resource;

public class CollectServicesHashSet {
	Set<Resource> resources = new HashSet<>();
	SimpleDateFormat simpleFormat = new SimpleDateFormat("dd/mm/yyyy");
	
	public void addResource(Resource resource)
	{
		resources.add(resource);
	}
	
	public void removeResource(int userId)
	{
		Iterator<Resource> iterator = resources.iterator();
		while (iterator.hasNext()) {
			Resource resource = iterator.next();
			if(resource.getUserId() == userId)
			{
				resources.remove(resource);
				break;
			}
			//System.out.println("No such resource found");
		}
	}
	
	public void displayDetails() {
		//Collections.sor;
		Iterator<Resource> iterator = resources.iterator();
		while (iterator.hasNext()) {
			Resource resource = iterator.next();
			System.out.println(resource);
		}
	}
}
