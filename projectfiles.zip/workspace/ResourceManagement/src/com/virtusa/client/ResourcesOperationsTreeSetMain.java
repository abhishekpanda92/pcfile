package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.virtusa.model.Resource;
import com.virtusa.services.CollectionServicesTreeSet;

public class ResourcesOperationsTreeSetMain {
	public static void main(String[] args) {

		int noOfIterations = 3;
		CollectionServicesTreeSet collectionServicesTreeSet = new CollectionServicesTreeSet();
		InputStreamReader is = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(is);
		
		while (noOfIterations > 0) {
			noOfIterations--;
			System.out.println("Enter Resource Id");
			int userId = 0;
			String name = null;
			Date hireDate = null;
			double compensation = 0;
			try {
				userId = Integer.parseInt(br.readLine());
				System.out.println("Enter Resource Name");
				name = br.readLine();
				System.out.println("Enter Resource HireDate(dd/mm/yyyy)");
				SimpleDateFormat simpleFormat = new SimpleDateFormat(
						"dd/mm/yyyy");
				hireDate = null;
				try {
					hireDate = simpleFormat.parse(br.readLine());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Enter Resource Compensation");
				compensation = Double.parseDouble(br.readLine());
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Resource resource = new Resource(userId, name, hireDate,
					compensation);

			collectionServicesTreeSet.addResource(resource);

		}

		Scanner scanner1 = new Scanner(System.in);
		System.out.println("Do you want to Remove any Resource");
		String choice = scanner1.nextLine();

		if (choice.equalsIgnoreCase("y")) {
			System.out.println("Enter Resource Id");
			int userId = scanner1.nextInt();
			collectionServicesTreeSet.removeResource(userId);
			collectionServicesTreeSet.displayDetails();
		} else {
			collectionServicesTreeSet.displayDetails();
			scanner1.close();
		}
	}
}
