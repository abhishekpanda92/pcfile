package com.virtusa.maptest;

import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.util.Map;

import com.virtusa.model.Resource;

public class TestMap {

	public static void main(String[] args) throws IOException
	{
//		Map<String,Resource> balanceSheets = new Hashtable<>();
//		Resource resource= new Resource(100,"Abhishek",new Date(),105.0);
//		balanceSheets.put(String.valueOf(100),resource);
//		resource= new Resource(101,"Abhishek1",new Date(),106.0);
//		balanceSheets.put(String.valueOf(101),resource);
//		resource= new Resource(102,"Abhishek2",new Date(),107.0);
//		balanceSheets.put(String.valueOf(102),resource);
//		
//		for (Resource value : balanceSheets.values()) {
//		    System.out.println("Value = " + value);
//		}
		//System.out.write(97); //prints ascii value
		//int i = System.in.read();
		System.out.write(300);
	}
	
	
	
	
	
}
