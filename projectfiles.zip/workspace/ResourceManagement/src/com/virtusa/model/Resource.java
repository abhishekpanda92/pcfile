package com.virtusa.model;

import java.util.Date;

public class Resource implements Comparable<Resource> {
	private int userId;
	private String name;
	private Date hireDate;
	private double compensation;

	public Resource() {

	}

	public Resource(int userId, String name, Date hireDate, double compensation) {
		this.userId = userId;
		this.name = name;
		this.hireDate = hireDate;
		this.compensation = compensation;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		Resource resource = (Resource) arg0;
		if (this.userId == resource.getUserId()) {
			return true;
		} else
			return false;

	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return this.userId;
	}

	public double getCompensation() {
		return compensation;
	}

	public void setCompensation(double compensation) {
		this.compensation = compensation;
	}

	@Override
	public String toString() {
		return "Resource [userId =" + userId + ", name = " + name
				+ ", hireDate = " + hireDate + ", compensation = "
				+ compensation + "]";
	}

	@Override
	public int compareTo(Resource arg0) {
		// TODO Auto-generated method stub
		
		//int k = arg0.userId;
		return this.name.compareTo(arg0.getName());
	}

}
