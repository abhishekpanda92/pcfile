package com.virtusa.model;

public class BankAccount {

	private int bankAccNumber;
	private String name;
	private double balance;

	public BankAccount(int employeeCode, String name, double balance) {
		// super();
		this.bankAccNumber = employeeCode;
		this.name = name;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "BankAccount [bankAccNumber = " + bankAccNumber + ", name = "
				+ name + ", balance=" + balance + "]";
	}

	public int getAccNumber() {
		return this.bankAccNumber;
	}

	public void setAccNumber(int bankAccNumber) {
		this.bankAccNumber = bankAccNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
}
