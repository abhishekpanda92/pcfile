package com.virtusa.userdefinedBankingexceptions;

public class InsufficientBalanceException extends Exception {

	/**
	 * 
	 */
	private String message;
	private static final long serialVersionUID = 1L;

	public InsufficientBalanceException(double price) {
		// TODO Auto-generated constructor stub
		this.message = "Insufficient funds...." + price
				+ " cannot be withdrawn due to Insufficient funds";
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return message;
	}
}
