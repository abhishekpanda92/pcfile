package com.virtusa.userdefinedBankingexceptions;

public class InvalidAccountNumberException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private String message;

    public InvalidAccountNumberException() {
		// TODO Auto-generated constructor stub
		this.message =  "InvalidAccountNumberException...." ;
	}
	public InvalidAccountNumberException(int accNo) {
		// TODO Auto-generated constructor stub
		this.message =  "InvalidAccountNumber...."+accNo;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return message;
	}
}
