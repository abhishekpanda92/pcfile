package com.virtusa.userdefinedBankingexceptions;


public class AlreadyExistingBankAccountException extends Exception {

	/**
	 * 
	 */
	private String message;
	private static final long serialVersionUID = 1L;

	public AlreadyExistingBankAccountException(int accNumber) {
		// TODO Auto-generated constructor stub
		this.message = "AlreadyExistingBankAccountException...." + accNumber
				+ " already exists";
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return message;
	}
}