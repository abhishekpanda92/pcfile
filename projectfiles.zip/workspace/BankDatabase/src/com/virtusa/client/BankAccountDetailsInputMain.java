package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.virtusa.model.BankAccount;
import com.virtusa.services.BankAccountDaoImplementation;
import com.virtusa.userdefinedBankingexceptions.AlreadyExistingBankAccountException;
import com.virtusa.userdefinedBankingexceptions.InsufficientBalanceException;
import com.virtusa.userdefinedBankingexceptions.InvalidAccountNumberException;
import com.virtusa.userdefinedBankingexceptions.InvalidAmountException;

public class BankAccountDetailsInputMain {

	private BankAccountDaoImplementation bankAccountDaoImplementation = new BankAccountDaoImplementation();
	private InputStreamReader inputStreamReader = new InputStreamReader(
			System.in);
	private BufferedReader bufferedReader = new BufferedReader(
			inputStreamReader);

	public void enterAccountDetails() {

		int accNo = 0;
		String name = null;
		double balance = 0.0;

		try {
			System.out.println("Enter your accNo");
			accNo = Integer.parseInt(bufferedReader.readLine());

			System.out.println("Enter your Name");
			name = bufferedReader.readLine();

			System.out.println("Enter your balance");
			balance = Double.parseDouble(bufferedReader.readLine());
			BankAccount bankAccount = new BankAccount(accNo, name, balance);
			try {
				bankAccountDaoImplementation.createAccount(bankAccount);
			} catch (AlreadyExistingBankAccountException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}

	}

	public void displayAccountName(int accNumber) {

		String result = null;
		try {
			result = bankAccountDaoImplementation.fetchName(accNumber);
		} catch (InvalidAccountNumberException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		if (result != null)
			System.out.println(result);

	}

	public void displayAccountBalance(int accNumber) {

		double result = 0.0;
		try {
			result = bankAccountDaoImplementation.fetchBalance(accNumber);
		} catch (InvalidAccountNumberException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		System.out.println(result);

	}

	public void fundTransfer() {

		try {
			System.out.println("Enter your accNo");
			int accNo1 = Integer.parseInt(bufferedReader.readLine());

			System.out.println("Enter the destination accNo");
			int accNo2 = Integer.parseInt(bufferedReader.readLine());

			System.out.println("Enter the amount to transfer");
			double amount = Double.parseDouble(bufferedReader.readLine());
			bankAccountDaoImplementation.fundTransfer(accNo1, accNo2, amount);
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidAccountNumberException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		} catch (InvalidAmountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InsufficientBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
