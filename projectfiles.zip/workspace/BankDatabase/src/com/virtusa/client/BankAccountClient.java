package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import com.virtusa.userdefinedBankingexceptions.UnSupportedServiceException;


public class BankAccountClient {

	public static void main(String[] args) throws UnSupportedServiceException {
		System.out.println(".........ONLINE BANKING.........");

		// Common Objects for all the operations
		InputStreamReader inputStreamReader = new InputStreamReader(System.in);
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		BankAccountDetailsInputMain bankAccountDetailsInputMain = new BankAccountDetailsInputMain();

		// 1 for employee creation and 2 for viewing employee details
		System.out
				.println("Do want to create new account(1),view name(2),view balance(3),transfer fund(4)?");
		String response = null;
		try {
			response = bufferedReader.readLine();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			System.out.println(e2);
		}

		if (response.equals(String.valueOf(1))) {
			bankAccountDetailsInputMain.enterAccountDetails();
		}
		else if(response.equals(String.valueOf(2)))
		{
			System.out.println("Enter the accNo for name");
			try {
				int accNo = Integer.parseInt(bufferedReader.readLine());
				bankAccountDetailsInputMain.displayAccountName(accNo);
				
			}  catch (NumberFormatException | IOException e2) {
				// TODO Auto-generated catch block
				System.out.println(e2);
			} 
		}
		else if(response.equals(String.valueOf(3)))		
		{
			System.out.println("Enter the accNo for balance");
			try {
				int accNo = Integer.parseInt(bufferedReader.readLine());
				bankAccountDetailsInputMain.displayAccountBalance(accNo);
				
			}  catch (NumberFormatException | IOException e2) {
				// TODO Auto-generated catch block
				System.out.println(e2);
			} 
			
		}
		else if(response.equals(String.valueOf(4)))
		{
			bankAccountDetailsInputMain.fundTransfer();
		}
		else
		{
			throw new UnSupportedServiceException("UnSupportedServiceException..."+"Service not Supported");
		}
	}
}
