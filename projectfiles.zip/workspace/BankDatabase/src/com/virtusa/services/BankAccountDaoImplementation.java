package com.virtusa.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.virtusa.databaseservices.OracleConnection;
import com.virtusa.model.BankAccount;
import com.virtusa.userdefinedBankingexceptions.AlreadyExistingBankAccountException;
import com.virtusa.userdefinedBankingexceptions.InsufficientBalanceException;
import com.virtusa.userdefinedBankingexceptions.InvalidAccountNumberException;
import com.virtusa.userdefinedBankingexceptions.InvalidAmountException;

public class BankAccountDaoImplementation implements BankAccountDao {

	private Connection connection = OracleConnection.getConnection();
	private CallableStatement callableStatement;
	private Statement statement;

	private BankAccount fetchBankAccount(int accNumber) {
		// TODO Auto-generated method stub

		BankAccount bankAccount = null;
		try {
			statement = connection.createStatement();
			String sql = ("SELECT * FROM BANKACCOUNTS where accnumber = " + accNumber);
			ResultSet rs = null;
			rs = statement.executeQuery(sql);
			if(rs.next())
			{
			int accountNumber = rs.getInt(1);
			String name = rs.getString(2);
			double balance = rs.getDouble(3);
			bankAccount = new BankAccount(accountNumber, name, balance);
			return bankAccount;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bankAccount;

	}

	@Override
	public int createAccount(BankAccount bankAccount)
			throws AlreadyExistingBankAccountException {
		// TODO Auto-generated method stub
		if (fetchBankAccount(bankAccount.getAccNumber()) != null)
			throw new AlreadyExistingBankAccountException(
					bankAccount.getAccNumber());

		try {
			callableStatement = connection
					.prepareCall("{call insert_bankAccount(?,?,?)}");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			callableStatement.setInt(1, bankAccount.getAccNumber());
			callableStatement.setString(2, bankAccount.getName());
			callableStatement.setDouble(3, bankAccount.getBalance());

			boolean result = callableStatement.execute();
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 1;
	}

	@Override
	public double fetchBalance(int accNumber)
			throws InvalidAccountNumberException {
		// TODO Auto-generated method stub
		BankAccount bankAccount = fetchBankAccount(accNumber);
		if (bankAccount == null)
			throw new InvalidAccountNumberException(accNumber);
		return bankAccount.getBalance();
	}

	@Override
	public String fetchName(int accNumber) throws InvalidAccountNumberException {
		// TODO Auto-generated method stub
		BankAccount bankAccount = fetchBankAccount(accNumber);
		if (bankAccount == null)
			throw new InvalidAccountNumberException(accNumber);
		return bankAccount.getName();
	}

	@Override
	public void fundTransfer(int accNo1, int accNo2, double amount)
			throws InvalidAccountNumberException, InvalidAmountException,
			InsufficientBalanceException {

		if (fetchBankAccount(accNo1) == null
				|| fetchBankAccount(accNo2) == null) {
			throw new InvalidAccountNumberException();
		}

		double balanceAcc1 = fetchBalance(accNo1);
		double balanceAcc2 = fetchBalance(accNo2);

		if (balanceAcc1 > amount) {
			if (amount <= 0) {
				throw new InvalidAmountException(amount);
			} else {

				String sql = "update bankaccounts set balance =(?) where accnumber = (?)";
				try {
					callableStatement = connection.prepareCall(sql);
					callableStatement.setDouble(1, balanceAcc1 - amount);
					callableStatement.setInt(2, accNo1);
					boolean result = callableStatement.execute();
					System.out.println(result);

					callableStatement = connection.prepareCall(sql);
					callableStatement.setDouble(1, balanceAcc2 + amount);
					callableStatement.setInt(2, accNo2);
					result = callableStatement.execute();
					System.out.println(result);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else {
			throw new InsufficientBalanceException(amount);
		}
	}

}
