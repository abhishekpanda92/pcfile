package com.virtusa.services;

import com.virtusa.model.BankAccount;
import com.virtusa.userdefinedBankingexceptions.AlreadyExistingBankAccountException;
import com.virtusa.userdefinedBankingexceptions.InsufficientBalanceException;
import com.virtusa.userdefinedBankingexceptions.InvalidAccountNumberException;
import com.virtusa.userdefinedBankingexceptions.InvalidAmountException;

public interface BankAccountDao {
	public int createAccount(BankAccount bankAccount)
			throws AlreadyExistingBankAccountException;

	public double fetchBalance(int accNumber)
			throws InvalidAccountNumberException;

	public String fetchName(int accNumber) throws InvalidAccountNumberException;

	public void fundTransfer(int source, int destination,
			double amount) throws InvalidAccountNumberException,
			InsufficientBalanceException, InvalidAmountException;
}
