package com.virtusa.services;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.model.User;

public class UserServices {

	List<User> userList = new ArrayList<>();

	public void addUsers(User user) {
		userList.add(user);
	}
	
	public void  saveUsers() throws IOException
	{
		FileOutputStream fout = new FileOutputStream("C:\\database\\users.ser");
		ObjectOutputStream oOut = new ObjectOutputStream(fout);

		oOut.writeObject(userList);

		oOut.close();

	}
	
	public User retrieveUsersByName(String firstName,String lastName) throws ClassNotFoundException, IOException
	{
		FileInputStream fin = new FileInputStream("C:\\database\\users.ser");

		ObjectInputStream oIn = new ObjectInputStream(fin);
		ArrayList<User> userListSaved = (ArrayList<User>) oIn.readObject();
		User user = new User();
		
		for (int i = 0; i < userListSaved.size(); i++) {
			if (userListSaved.get(i).getFirstName().equals(firstName) && userListSaved.get(i).getLastName().equals(lastName)) {
				user = userListSaved.get(i);
				fin.close();
				oIn.close();
				return user;
			}
		}

		fin.close();
		return user;
	}
}
