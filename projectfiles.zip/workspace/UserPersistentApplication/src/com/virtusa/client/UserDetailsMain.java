package com.virtusa.client;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.virtusa.databaseservices.OracleDatabaseConnection;
import com.virtusa.model.User;
import com.virtusa.services.UserServices;

public class UserDetailsMain {

	private Connection connection = OracleDatabaseConnection.connect();

	public static void main(String[] args) throws SQLException {
		User user1 = new User("Rohan", "Kumble", "ak@gmail.com", 95074l);
		User user2 = new User("Lokesh", "Ganguly", "ap1@gmail.com", 9503370775l);
		User user3 = new User("Agarkar", "Rahul", "ap2@gmail.com", 9503370776l);
		User user4 = new User("Kanhitkar", "Dravid", "ap3@gmail.com",
				9503370777l);
		User user5 = new User("Kambli", "Anil", "ap4@gmail.com", 9503370778l);

		UserDetailsMain userDetailsMain = new UserDetailsMain();
		userDetailsMain.insertUser(user1);
		userDetailsMain.insertUser(user2);
		userDetailsMain.insertUser(user3);
		userDetailsMain.insertUser(user4);
		userDetailsMain.insertUser(user5);

		userDetailsMain.printResults();

		// Statement statement = null;
		// PreparedStatement preparedStatement = null;

		// try {
		// // String query = makeQueryForInsert(user1);
		// // statement.executeUpdate(query);
		// //
		// // query = makeQueryForInsert(user2);
		// // statement.executeUpdate(query);
		// //
		// // query = makeQueryForInsert(user3);
		// // statement.executeUpdate(query);
		// //
		// // query = makeQueryForInsert(user4);
		// // statement.executeUpdate(query);
		// //
		// // query = makeQueryForInsert(user5);
		// // statement.executeUpdate(query);
		//
		// preparedStatement =
		// connection.prepareStatement("INSERT INTO userdetails (firstName, lastName, emailId, phoneNo) VALUES (?, ?, ?, ?)");
		// preparedStatement.setString(1, user1.getFirstName());
		// preparedStatement.setString(2, user1.getLastName());
		// preparedStatement.setString(3, user1.getEmailId());
		// preparedStatement.setLong(4,user1.getContactNumber() );
		//
		// preparedStatement.executeUpdate();
		//

		//
		//
		// } catch (SQLException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
	}

	//
	// private static PreparedStatement makeQueryForInsert(User user1) {
	// // TODO Auto-generated method stub
	//
	// PreparedStatement
	// }

	private void printResults() throws SQLException {

		String sql = ("SELECT * FROM userdetails");
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = preparedStatement.executeQuery();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			while (rs.next()) {
				String firstName = rs.getString(1);
				String lastName = rs.getString(2);
				String emailId = rs.getString(3);
				long phoneNo = rs.getLong(4);
				System.out.println(firstName + " " + lastName + " " + emailId
						+ " " + phoneNo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		sql = "delete from userdetails where lastname = 'Modi'";
		preparedStatement = connection.prepareStatement(sql);
		int i = preparedStatement.executeUpdate();
		System.out.println();
		System.out.println(i);
		

	}

	private void insertUser(User user) {

		CallableStatement callableStatement = null;
		try {
			callableStatement = connection
					.prepareCall("{call insert_user(?,?,?,?)}");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			callableStatement.setString(1, user.getFirstName());
			callableStatement.setString(2, user.getLastName());
			callableStatement.setString(3, user.getEmailId());
			callableStatement.setLong(4, user.getContactNumber());
			boolean result = callableStatement.execute();
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
