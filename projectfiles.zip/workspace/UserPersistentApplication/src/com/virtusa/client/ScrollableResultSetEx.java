package com.virtusa.client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;

import com.virtusa.databaseservices.OracleDatabaseConnection;

public class ScrollableResultSetEx {

	public static void main(String[] args) throws SQLException {
		Connection connection = OracleDatabaseConnection.connect();
		PreparedStatement preparedStatement = connection.prepareStatement(
				"select firstname,lastname from userdetails", ResultSet.TYPE_SCROLL_SENSITIVE,
				ResultSet.CONCUR_UPDATABLE);
		ResultSet rs = preparedStatement.executeQuery();
		
		Statement statement = connection.createStatement();
		
		//EXECUTE A BATCH
//		statement.addBatch("");
//		statement.addBatch("");
//		statement.addBatch("");
//		statement.addBatch("");
//		statement.executeBatch();
		
		//MOVEMENT OF CURSOR AND DELETION OF ROWS AND UPDATION(?)
//		rs.first();  //concurr read only doesnt allow to delete the row only read
//		rs.deleteRow();
//		rs.absolute(5);
//		rs.updateString(2,"Mohapatra");
//		rs.beforeFirst();
		while (rs.next()) {
			System.out.println(rs.getString(1) + " " + rs.getString(2) + " "
					+ rs.getString(3) + " " + rs.getLong(4));
		}
	}
}
