package com.virtusa.client;

import com.virtusa.model.Department;
import com.virtusa.model.Employee;
import com.virtusa.services.MapServices;

public class EmployeeDepartmentMain {

	public static void main(String[] args)
	{
		Employee emp1 = new Employee(100,"abhishek1",150.0);
		Employee emp2 = new Employee(200,"abhishek2",250.0);
		Employee emp3 = new Employee(300,"abhishek3",350.0);
		Employee emp4 = new Employee(400,"abhishek4",450.0);
		Employee emp5 = new Employee(500,"abhishek5",550.0);
		
		Department dep1 = new Department(1001,"Training","Bangalore");
		Department dep2 = new Department(1002,"SharedServices","Hyderabad");
		Department dep3 = new Department(1003,"Technology","Colombo");
		Department dep4 = new Department(1004,"Testing","Pune");
		Department dep5 = new Department(1005,"Security","Chennai");
		
		MapServices mapServices = new MapServices();
		mapServices.add(emp1, dep1);
		mapServices.add(emp2, dep2);
		mapServices.add(emp3, dep3);
		mapServices.add(emp4, dep4);
		mapServices.add(emp5, dep5);
		
		mapServices.displayDetails();
		
	}
}
