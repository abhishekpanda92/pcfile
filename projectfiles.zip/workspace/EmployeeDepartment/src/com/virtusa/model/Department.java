package com.virtusa.model;

public class Department implements Comparable<Department> {
	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptName=" + deptName
				+ ", deptLocation=" + deptLocation + "]";
	}

	private int deptId;
	private String deptName;
	private String deptLocation;

	public Department() {

	}

	public Department(int deptId, String deptName, String deptLocation) {
		this.deptId = deptId;
		this.deptName = deptName;
		this.deptLocation = deptLocation;

	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptLocation() {
		return deptLocation;
	}

	public void setDeptLocation(String deptLocation) {
		this.deptLocation = deptLocation;
	}

	@Override
	public int compareTo(Department arg0) {
		// TODO Auto-generated method stub
		return this.deptName.compareTo(arg0.deptName);
	}

}
