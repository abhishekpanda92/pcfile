package com.virtusa.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.virtusa.model.Department;
import com.virtusa.model.Employee;

public class MapServices {

	private Map<Employee, Department> map = new HashMap<>();

	public void add(Employee employee, Department department) {
		map.put(employee, department);
	}

	public void displayDetails() {
		
		Set<Entry<Employee, Department>> set = map.entrySet();
		List<Entry<Employee, Department>> list = new ArrayList<Entry<Employee, Department>>(
				set);
		Collections.sort(list,
				new Comparator<Map.Entry<Employee, Department>>() {
					public int compare(Map.Entry<Employee, Department> o1,
							Map.Entry<Employee, Department> o2) {
						return (o1.getValue()).getDeptName().compareTo(
								o2.getValue().getDeptName());
					}
				});
		for (Entry<Employee, Department> entry : list) {
			System.out.println(entry.getKey() + " ==== " + entry.getValue());
		}
//		List<Department> departments = new ArrayList<Department>(map.values());
//		Collections.sort(departments);
//
//		for (int i = 0; i < departments.size(); i++)
//			System.out.println(departments.get(i));
	}

}
