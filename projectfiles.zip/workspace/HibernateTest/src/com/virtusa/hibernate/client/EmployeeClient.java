package com.virtusa.hibernate.client;

import org.hibernate.*;
import org.hibernate.cfg.*;

import com.virtusa.hibernate.pojo.Employee;

public class EmployeeClient {

	public static void main(String[] args) {

		
		Employee emp = new Employee();
		emp.setEmpId(106);
		emp.setEmpName("employee5");
		emp.setEmpAddress("banglore");

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		
		Transaction tx = session.beginTransaction();
		
		session.save(emp);
		//session.persist(emp);
		
		//session.delete(emp);
		
		//session.update(emp);
		//session.saveOrUpdate(emp);
		
		//Employee emp1 = (Employee)session.get(Employee.class,102);
		
		//Employee emp1 = (Employee)session.load(Employee.class, 103);
		//System.out.println("Object saved successfully.....!!" + emp1.getEmpId()+" "+ emp1.getEmpName()+" "+ emp1.getEmpAddress());
		tx.commit();
		session.close();
		factory.close();
	}
}
