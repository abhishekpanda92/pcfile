package com.virtusa.model;

public class BankAccount {

	private int accNo;
	private String name;
	private long phoneNo;
	private String emailId;
	private int balance;

	public BankAccount() {
        
	}

	public BankAccount(int accNo, String name, long phoneNo, String emailId,int balance) {
		this.accNo = accNo;
		this.name = name;
		this.phoneNo = phoneNo;
		this.emailId = emailId;
		this.balance = balance;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public int getBalance()
	{
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	
}
