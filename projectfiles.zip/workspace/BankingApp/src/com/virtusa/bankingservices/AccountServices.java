package com.virtusa.bankingservices;

import com.virtusa.model.BankAccount;
import com.virtusa.userdefinedexceptions.InvalidAccountNumberException;

public class AccountServices {

	private static int[] accNo = { 1001, 1002, 1003, 1004, 1005 };
	private static String[] names = { "Abhishek", "Sachin", "Saurav", "Virat",
			"Dravid" };
	private static long[] phoneNos = { 950337774, 950337775, 950337776,
			950337777, 950337778 };
	private static String[] emailIds = { "abhishek@gmail.com",
			"sachin@gmail.com", "saurav@gmail.com", "virat@gmail.com",
			"dravid@gmail.com" };
	private static int[] balances = { 100000, 50000, 40000, 30000, 38000};
	private static BankAccount[] bankAccount = new BankAccount[5];

	// initialise();

	public static void fillBankAccounts() {
		for (int i = 0; i < bankAccount.length; i++) {
			bankAccount[i] = new BankAccount(accNo[i], names[i], phoneNos[i],
					emailIds[i], balances[i]);
		}
	}

	public BankAccount findAccountDetails(int accNo) {
		for (int i = 0; i < bankAccount.length; i++) {
			if (accNo == bankAccount[i].getAccNo()) {
				return bankAccount[i];
			}
		}

		BankAccount bankAccount = null;
		return bankAccount;
		// bankAccount[0] = new invalidAccountNumberException();
	}

	public boolean validateAccount(int accNo)
			throws InvalidAccountNumberException {
		boolean status = false;
		for (int i = 0; i < bankAccount.length; i++) {
			if (accNo == bankAccount[i].getAccNo()) {
				status = true;
				return status;
			}
		}

		throw new InvalidAccountNumberException(accNo);

	}

}
