package com.virtusa.bankingservices;

import com.virtusa.model.BankAccount;
import com.virtusa.userdefinedexceptions.InsufficientBalanceException;
import com.virtusa.userdefinedexceptions.InvalidAccountNumberException;
import com.virtusa.userdefinedexceptions.InvalidAmountException;

public class AccountOperations {

	private AccountServices accountServices = new AccountServices();

	public AccountOperations() {
		AccountServices.fillBankAccounts();
	}

	public void depositMoneyOperation(int accNo, int amount)
			throws InvalidAmountException, InvalidAccountNumberException {
		accountServices.validateAccount(accNo);
		AccountServices accountServices = new AccountServices();
		BankAccount bankAccount = accountServices.findAccountDetails(accNo);
		int availableBalance = bankAccount.getBalance();
		if (amount > 0)
			bankAccount.setBalance(availableBalance + amount);
		else {
			throw new InvalidAmountException(amount);
		}

	}

	public void withdrawMoneyOperation(int accNo, int amount)
			throws InsufficientBalanceException, InvalidAmountException,
			InvalidAccountNumberException {
		accountServices.validateAccount(accNo);
		BankAccount bankAccount = null;

		bankAccount = accountServices.findAccountDetails(accNo);
		int availableBalance = bankAccount.getBalance();
		if (availableBalance >= amount && amount >= 0)
			bankAccount.setBalance(availableBalance - amount);
		else {

			if (amount <= 0) {
				throw new InvalidAmountException(amount);
			}
			throw new InsufficientBalanceException(amount);

		}

	}

	public int balanceEnquiryOperation(int accNo)
			throws InvalidAccountNumberException {
		accountServices.validateAccount(accNo);
		BankAccount bankAccount = accountServices.findAccountDetails(accNo);
		return bankAccount.getBalance();

	}

	public void balanceTransfer(int accNo1, int accNo2, int amount)
			throws InvalidAccountNumberException, InvalidAmountException,
			InsufficientBalanceException {
		accountServices.validateAccount(accNo1);
		accountServices.validateAccount(accNo2);

		int balanceAcc1 = balanceEnquiryOperation(accNo1);
		int balanceAcc2 = balanceEnquiryOperation(accNo2);

		if (balanceAcc1 > amount) {
			if (amount <= 0) {
				throw new InvalidAmountException(amount);
			} else {
				BankAccount bankAccount1 = accountServices
						.findAccountDetails(accNo1);
				bankAccount1.setBalance(balanceAcc1 - amount);

				BankAccount bankAccount2 = accountServices
						.findAccountDetails(accNo2);
				bankAccount2.setBalance(balanceAcc2 + amount);

			}
		} else {
			throw new InsufficientBalanceException(amount);
		}
	}
}
