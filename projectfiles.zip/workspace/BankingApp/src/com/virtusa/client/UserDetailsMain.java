package com.virtusa.client;

import java.util.Scanner;

import com.virtusa.bankingservices.AccountOperations;
import com.virtusa.bankingservices.AccountServices;
import com.virtusa.userdefinedexceptions.InsufficientBalanceException;
import com.virtusa.userdefinedexceptions.InvalidAccountNumberException;
import com.virtusa.userdefinedexceptions.InvalidAmountException;
import com.virtusa.userdefinedexceptions.UnSupportedServiceException;

public class UserDetailsMain {

	static {
		//AccountServices.fillBankAccounts();
	}

	public static void main(String args[]) throws InvalidAmountException, InvalidAccountNumberException {

		Scanner scanner = new Scanner(System.in);
		AccountOperations accountOperations = new AccountOperations();
		AccountServices accountServices = new AccountServices();

		System.out.println("Please Enter your Account No.");
		int accNo = scanner.nextInt();

		int amount = 0;
		boolean continuation = false;
		try {
			continuation = accountServices.validateAccount(accNo);
		} catch (InvalidAccountNumberException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if (continuation) {
			System.out
					.println("Please Enter the Operation you want to perform (DEPOSIT-D,WITHDRAW-W,CHECKBALANCE-C)");
			String operation = scanner.next();
			if (operation.equalsIgnoreCase("D")) {
				System.out.println("Please Enter the Amount.");
				amount = scanner.nextInt();
				accountOperations.depositMoneyOperation(accNo, amount);
			} 
			else if (operation.equalsIgnoreCase("C"))
			{
				accountOperations.balanceEnquiryOperation(accNo);
			} 
			else if (operation.equalsIgnoreCase("W"))
			{
				accountOperations = new AccountOperations();
				System.out.println("Please Enter the Amount.");
				amount = scanner.nextInt();
				try {
					accountOperations.withdrawMoneyOperation(accNo, amount);
				} catch (InsufficientBalanceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
			else {
				scanner.close();
				try {
					throw new UnSupportedServiceException(
							"Not Suppoted Operation");
				} catch (UnSupportedServiceException e) {
					// TODO Auto-generated catch block
					System.out.println(e);
				} 
			}
		}
		scanner = new Scanner(System.in);
		System.out.println("Enter Y to continue");
		String option = scanner.nextLine();

		if (option.equalsIgnoreCase("Y")) {
			main(args);
		}
		else
		{
			scanner.close();
		}
	}
}
