package com.virtusa.userdefinedexceptions;

public class UnSupportedServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message;

	public UnSupportedServiceException(String message ) {
		// TODO Auto-generated constructor stub
		this.message = message;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return message;
	}
}
