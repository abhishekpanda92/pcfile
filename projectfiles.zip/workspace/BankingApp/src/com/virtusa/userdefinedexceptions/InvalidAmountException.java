package com.virtusa.userdefinedexceptions;


public class InvalidAmountException extends Exception {

	/**
	 * 
	 */
	private String message;
	private static final long serialVersionUID = 1L;

	public InvalidAmountException(int price) {
		// TODO Auto-generated constructor stub
		this.message = "Invalid...." + price
				+ " cannot be withdrawn due it being negative";
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return message;
	}
}
