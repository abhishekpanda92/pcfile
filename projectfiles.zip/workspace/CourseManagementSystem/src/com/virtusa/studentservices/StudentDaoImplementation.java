package com.virtusa.studentservices;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.virtusa.courseservices.CourseManagementImplementation;
import com.virtusa.databaseservices.OracleConnection;
import com.virtusa.model.Course;
import com.virtusa.model.Student;
import com.virtusa.userdefinedexceptions.InvalidCourseIdException;
import com.virtusa.userdefinedexceptions.InvalidEnrollmentIdException;

public class StudentDaoImplementation implements StudentDao {

	private Connection connection = OracleConnection.getConnection();
	private CallableStatement callableStatement;
	private Statement statement;
	private CourseManagementImplementation courseManagementImplementation = new CourseManagementImplementation();

	@Override
	public void addStudent(Student student) throws InvalidCourseIdException {
		// TODO Auto-generated method stub

		Course course = courseManagementImplementation.findCourseById(student
				.getCourseId());
		if (course == null) {
			throw new InvalidCourseIdException(student.getCourseId());
		}

		try {
			callableStatement = connection
					.prepareCall("{call insert_student(?,?,?,?)}");
			callableStatement.setInt(1, student.getEnrollmentId());
			callableStatement.setString(2, student.getName());
			callableStatement.setString(3, student.getEnrollDate());
			callableStatement.setInt(4, student.getCourseId());

			boolean result = callableStatement.execute();
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void viewAllStudents() {
		// TODO Auto-generated method stub
		try {
			statement = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql = ("SELECT * FROM students");
		ResultSet rs = null;
		try {
			rs = statement.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // ResultSet is an interface

		try {
			while (rs.next()) {
				int enrollId = rs.getInt(1);
				String name = rs.getString(2);
				String enrollDate = rs.getString(3);
				int courseId = rs.getInt(4);
				Student student = new Student(enrollId, name, enrollDate,
						courseId);
				System.out.println(student);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Student findStudentById(int enrollmentId)
			throws InvalidEnrollmentIdException {
		// TODO Auto-generated method stub
		Student student = null;
		try {
			statement = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql = ("SELECT * FROM students");
		ResultSet rs = null;
		try {
			rs = statement.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // ResultSet is an interface

		try {
			while (rs.next()) {
				int enrollId = rs.getInt(1);

				if (enrollId == enrollmentId) {
					String name = rs.getString(2);
					String enrollDate = rs.getString(3);
					int courseId = rs.getInt(4);
					student = new Student(enrollId, name, enrollDate, courseId);
					return student;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return student;
	}

	@Override
	public void findStudentCourses(int enrollmentId) {
		// TODO Auto-generated method stub
		
		String sql = "select courseId from students where enrollmentId =(?)";
		
		ResultSet rs = null;
		
		try {
			callableStatement = connection.prepareCall(sql);
			callableStatement.setInt(1, enrollmentId);
			rs = callableStatement.executeQuery();
			while (rs.next()) {
				int courseId = rs.getInt(1);
				System.out.println(courseManagementImplementation.findCourseById(courseId).getCourseName());

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidCourseIdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
	}

	@Override
	public void viewAllStudentsCourseNameandCourseId() {
		// TODO Auto-generated method stub
		
	}

}
