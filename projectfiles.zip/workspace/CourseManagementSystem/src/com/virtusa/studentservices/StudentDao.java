package com.virtusa.studentservices;

import com.virtusa.model.Student;
import com.virtusa.userdefinedexceptions.InvalidCourseIdException;
import com.virtusa.userdefinedexceptions.InvalidEnrollmentIdException;

public interface StudentDao {

	public void addStudent(Student student) throws InvalidCourseIdException;
	public void viewAllStudents();
	public Student findStudentById(int enrollmentId) throws InvalidEnrollmentIdException;
	public void findStudentCourses(int studentId); 
	public void viewAllStudentsCourseNameandCourseId();
}
