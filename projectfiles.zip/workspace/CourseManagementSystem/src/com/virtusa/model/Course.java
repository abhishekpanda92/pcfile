package com.virtusa.model;

import java.util.Date;

public class Course {
	
	private String courseName;
	private int courseId;
	private String courseStartDate;
	private String courseEndDate;
	@Override
	public String toString() {
		return "Course [courseName=" + courseName + ", courseId=" + courseId
				+ ", courseStartDate=" + courseStartDate + ", courseEndDate="
				+ courseEndDate + "]";
	}
	public Course(String courseName, int courseId, String courseStartDate,
			String courseEndDate) {
		//super();
		this.courseName = courseName;
		this.courseId = courseId;
		this.courseStartDate = courseStartDate;
		this.courseEndDate = courseEndDate;
	}
	public Course() {
		//super();
		// TODO Auto-generated constructor stub
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseStartDate() {
		return courseStartDate;
	}
	public void setCourseStartDate(String courseStartDate) {
		this.courseStartDate = courseStartDate;
	}
	public String getCourseEndDate() {
		return courseEndDate;
	}
	public void setCourseEndDate(String courseEndDate) {
		this.courseEndDate = courseEndDate;
	}

}
