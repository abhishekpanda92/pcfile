package com.virtusa.model;



public class Student {
	private int enrollmentId;
	private String name;
	private String enrollDate;

	@Override
	public String toString() {
		return "Student [enrollmentId=" + enrollmentId + ", name=" + name
				+ ", enrollDate=" + enrollDate + ", courseId=" + courseId + "]";
	}

	public Student(int enrollmentId, String name, String enrollDate,
			int courseId) {
		// super();
		this.enrollmentId = enrollmentId;
		this.name = name;
		this.enrollDate = enrollDate;
		this.courseId = courseId;
	}

	public Student() {
		// super();
		// TODO Auto-generated constructor stub
	}

	public int getEnrollmentId() {
		return enrollmentId;
	}

	public void setEnrollmentId(int enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEnrollDate() {
		return enrollDate;
	}

	public void setEnrollDate(String enrollDate) {
		this.enrollDate = enrollDate;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	private int courseId;

}