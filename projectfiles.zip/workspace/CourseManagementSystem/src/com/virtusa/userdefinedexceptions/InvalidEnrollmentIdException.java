package com.virtusa.userdefinedexceptions;

public class InvalidEnrollmentIdException extends Exception {

	/**
	 * 
	 */
	private String message;
	private static final long serialVersionUID = 1L;

	public InvalidEnrollmentIdException(int enrollmentId) {
		// TODO Auto-generated constructor stub
		this.message = "InvalidEnrollmentIdException...." + enrollmentId
				+ " does not exist";
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return message;
	}

}
