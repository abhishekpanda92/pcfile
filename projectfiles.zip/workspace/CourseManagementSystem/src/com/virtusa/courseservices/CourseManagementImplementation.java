package com.virtusa.courseservices;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.virtusa.databaseservices.OracleConnection;
import com.virtusa.model.Course;
import com.virtusa.userdefinedexceptions.InvalidCourseIdException;

public class CourseManagementImplementation implements CourseManagementDao {

	private Connection connection = OracleConnection.getConnection();
	private CallableStatement callableStatement;
	private Statement statement;

	@Override
	public void addCourse(Course course) {
		// TODO Auto-generated method stub
		try {
			callableStatement = connection
					.prepareCall("{call insert_course(?,?,?,?)}");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			callableStatement.setInt(1, course.getCourseId());
			callableStatement.setString(2, course.getCourseName());
			callableStatement.setString(3, course.getCourseStartDate());
			callableStatement.setString(4, course.getCourseEndDate());

			boolean result = callableStatement.execute();
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void viewAllCourses() {
		// TODO Auto-generated method stub
		try {
			statement = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql = ("SELECT * FROM courses");
		ResultSet rs = null;
		try {
			rs = statement.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // ResultSet is an interface

		try {
			while (rs.next()) {
				int courseIdFetch = rs.getInt(1);

				String courseName = rs.getString(2);
				String startDate = rs.getString(3);
				String endDate = rs.getString(4);
				Course course = new Course(courseName, courseIdFetch,
						startDate, endDate);
				System.out.println(course);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public Course findCourseById(int courseId) throws InvalidCourseIdException {
		// TODO Auto-generated method stub
		Course course = null;
		try {
			statement = connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql = ("SELECT * FROM courses");
		ResultSet rs = null;
		try {
			rs = statement.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // ResultSet is an interface

		try {
			while (rs.next()) {
				int courseIdFetch = rs.getInt(1);

				if (courseIdFetch == courseId) {
					String courseName = rs.getString(2);
					String startDate = rs.getString(3);
					String endDate = rs.getString(4);
					course = new Course(courseName, courseIdFetch, startDate,
							endDate);
					return course;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return course;
	}

}
