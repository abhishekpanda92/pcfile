package com.virtusa.courseservices;

import com.virtusa.model.Course;
import com.virtusa.userdefinedexceptions.InvalidCourseIdException;

public interface CourseManagementDao {

	public void addCourse(Course course);
	public void viewAllCourses();
	public Course findCourseById(int courseId) throws InvalidCourseIdException;
}
