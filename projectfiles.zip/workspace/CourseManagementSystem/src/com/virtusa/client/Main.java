package com.virtusa.client;

import com.virtusa.courseservices.CourseManagementImplementation;
import com.virtusa.model.Course;
import com.virtusa.model.Student;
import com.virtusa.studentservices.StudentDaoImplementation;
import com.virtusa.userdefinedexceptions.InvalidCourseIdException;
import com.virtusa.userdefinedexceptions.InvalidEnrollmentIdException;
import com.virtusa.utlity.UtilityClass;

public class Main {

	public static void main(String[] args) throws InvalidEnrollmentIdException {
		CourseManagementImplementation courseManagementImplementation = new CourseManagementImplementation();
		courseManagementImplementation.addCourse(new Course("History", UtilityClass.generateCourseId(),
				"14/11/2014", "27/11/2014"));
		courseManagementImplementation.addCourse(new Course("Maths", UtilityClass.generateCourseId(),
				"15/11/2014", "28/11/2014"));
		courseManagementImplementation.addCourse(new Course("Science", UtilityClass.generateCourseId(),
				"16/11/2014", "29/11/2014"));
		courseManagementImplementation.addCourse(new Course("Politics", UtilityClass.generateCourseId(),
				"17/11/2014", "30/11/2014"));
		courseManagementImplementation.viewAllCourses();
//		StudentDaoImplementation studentDaoImplementation = new StudentDaoImplementation();

//		try {
//			Student student = new Student(8018, "Abhishek", "13/11/2014", 3);
//			student.getCourseId();
//			studentDaoImplementation.addStudent(student);
//		} catch (InvalidCourseIdException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		studentDaoImplementation.findStudentCourses(8018);
	}
}
