package com.virtusa.utlity;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.databaseservices.OracleConnection;

public class UtilityClass {

	private static List<Integer> courseIds ;
	private static Connection connection = OracleConnection.getConnection();
	private static CallableStatement callableStatement;

	public static int generateCourseId() {
		updatecourseIds();
		int courseId = (int) (100 * Math.random());
		if (courseIds.contains(courseId)) {
			return generateCourseId();
		} else {
			//courseIds.add(courseId);
			try {
				saveArrayList(courseId);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return courseId;
		}
	}

	private static void saveArrayList(int courseId) throws IOException {
		String sql = "insert into  courseidtable values(?)";
		try {
			callableStatement = connection.prepareCall(sql);
			callableStatement.setInt(1,courseId);
			callableStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}

	private static void updatecourseIds() {
		courseIds = new ArrayList<Integer>();
		
		String sql = "select * from courseidtable";
		
		try {
			callableStatement = connection.prepareCall(sql);
			ResultSet rs = callableStatement.executeQuery();
			if(rs != null)
			{
				while(rs.next())
				{
					courseIds.add(rs.getInt(1));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
