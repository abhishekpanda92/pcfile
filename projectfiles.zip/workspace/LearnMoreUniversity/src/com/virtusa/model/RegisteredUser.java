package com.virtusa.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;

public class RegisteredUser {

	protected int userId;
	protected String name;
	protected Date dateOfBirth;
	protected String bloodGroup;
	protected Height height;
	private BufferedReader br;
	
	public RegisteredUser()
	{
		
	}

	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public Height getHeight() {
		return height;
	}
	public void setHeight(Height height) {
		this.height = height;
	}
	
	
	public void displayDetails(String fileName) {

		System.out.println("Enter your username");
		String name = null;
		int userId = 0;
		try {
			InputStreamReader is = new InputStreamReader(System.in);
			br = new BufferedReader(is);
			name = br.readLine();

			System.out.println("Enter your Id");
			userId = Integer.parseInt(br.readLine());
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		File file = new File("C://UserDataBase//"+fileName);

		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String line = null;
		try {
			while ((line = br.readLine()) != null) {

				if (line.split(",")[0].equals(name.trim())
						&& line.split(",")[1].equals(String.valueOf(userId))) {
					String details[] = line.split(",");
					
					if(this instanceof Employee)
					{
						String displayDetails = "Name: "+details[0] +"\n" + "IdNo: "+details[1] +"\n"
								+ "DateOfBirth: "+details[2] +"\n" + "BloodGroup: "+details[3] +"\n" + "Height feet: "+details[4] +" "
								+ "inches: "+details[5] +"\n" + "Designation: "+details[6] +"\n"+ "WorkStation: "+details[7] +"\n";
						System.out.println(displayDetails);
					}
					else
					{
						String displayDetails = "Name: "+details[0] +"\n" + "IdNo: "+details[1] +"\n"
								+ "DateOfBirth: "+details[2] +"\n" + "BloodGroup: "+details[3] +"\n" + "Height feet: "+details[4] +" "
								+ "inches: "+details[5] +"\n" + "Marks: "+details[6] +"\n";
						System.out.println(displayDetails);
					}
						
					break;
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
