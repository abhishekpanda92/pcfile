package com.virtusa.model;

public class Student extends RegisteredUser{
	
	
	private int marks;
	
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String studentInfo = name + "," + userId + "," + dateOfBirth + ","
				+ bloodGroup + "," + height + "," + marks;
				
		return studentInfo;
	}

	
}
