package com.virtusa.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Employee extends RegisteredUser {

	private String designation;
	private String workStationDetails;
	private BufferedReader br;

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getWorkStationDetails() {
		return workStationDetails;
	}

	public void setWorkStationDetails(String workStationDetails) {
		this.workStationDetails = workStationDetails;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String employeeInfo = name + " ," + userId + "," + dateOfBirth + ","
				+ bloodGroup + "," + height + "," + designation + ","
				+ workStationDetails;
		return employeeInfo;
	}
	
	


}
