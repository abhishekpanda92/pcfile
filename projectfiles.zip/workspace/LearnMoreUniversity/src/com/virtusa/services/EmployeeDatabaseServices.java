package com.virtusa.services;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


import com.virtusa.model.Employee;

public class EmployeeDatabaseServices {

	private FileWriter fileWriter;

	public void addEmployee(Employee employee) {
		// TODO Auto-generated method stub

		File file = new File("C://UserDataBase//EmployeeDb.txt");
		// PrintWriter out;

		try {
			fileWriter = new FileWriter(file, true);
			fileWriter.write(employee.toString());// appends the string to the
			// file
			fileWriter.write(System.getProperty("line.separator"));
			fileWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // the true will append the new data

	}


}
