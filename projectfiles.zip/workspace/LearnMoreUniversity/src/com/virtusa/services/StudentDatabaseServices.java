package com.virtusa.services;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


import com.virtusa.model.Student;

public class StudentDatabaseServices {

	private FileWriter fileWriter;

	public void addStudent(Student student) {
		// TODO Auto-generated method stub

		
		File file = new File("C://UserDataBase//StudentDb.txt");
		//PrintWriter out;

		try {
			fileWriter = new FileWriter(file,true);
			fileWriter.write(student.toString());//appends the string to the file
			fileWriter.write(System.getProperty("line.separator"));
			fileWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //the true will append the new data

	}

}
