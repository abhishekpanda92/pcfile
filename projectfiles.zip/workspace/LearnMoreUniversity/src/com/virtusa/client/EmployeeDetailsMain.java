package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.virtusa.model.Employee;
import com.virtusa.model.Height;
import com.virtusa.services.EmployeeDatabaseServices;

public class EmployeeDetailsMain {

	InputStreamReader is = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(is);

	public void getEmloyeeDetails() {
		String name = null;
		int userId = 0;
		Date dateBirth = null;
		String bloodGroup = null;
		int feet = 0;
		int inches = 0;
		String designation = null;
		String workStation = null;
		try {
			System.out.println("Enter your name");
			name = br.readLine().trim();

			System.out.println("Enter your Employee Id");
			userId = Integer.parseInt(br.readLine());

			System.out.println("Enter your date of Birth (dd/mm/yyyy)");
			SimpleDateFormat simpleFormat = new SimpleDateFormat("dd/mm/yyyy");
			String dateOfBirth = br.readLine().trim();
			dateBirth = simpleFormat.parse(dateOfBirth);

			System.out.println("Enter your BloodGroup");
			bloodGroup = br.readLine();

			System.out.println("Enter your Height(feet)");
			feet = Integer.parseInt(br.readLine());

			System.out.println("Enter your Height(inches)");
			inches = Integer.parseInt(br.readLine());

			System.out.println("Enter your Designation");
			designation = br.readLine();

			System.out.println("Enter your WorkStation");
			workStation = br.readLine();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Employee employee = new Employee();
		employee.setName(name);
		employee.setUserId(userId);
		employee.setDateOfBirth(dateBirth);
		employee.setBloodGroup(bloodGroup);
		Height height = new Height(feet, inches);
		employee.setHeight(height);
		employee.setWorkStationDetails(workStation);
		employee.setDesignation(designation);
		
		EmployeeDatabaseServices employeeDatabaseServices = new EmployeeDatabaseServices();
		//System.out.println(employee);
		employeeDatabaseServices.addEmployee(employee);

	}
}
