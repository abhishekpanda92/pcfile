package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.virtusa.model.Employee;
import com.virtusa.model.Height;
import com.virtusa.model.Student;
import com.virtusa.services.StudentDatabaseServices;

public class StudentDetailsMain {

	InputStreamReader is = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(is);

	public void getStudentDetails() {
		System.out.println("Enter your name");
		String name = null;
		int userId = 0;
		Date dateBirth = null;
		String bloodGroup = null;
		int feet = 0;
		int inches = 0;
		int marks = 0;
		try {
			name = br.readLine().trim();

			System.out.println("Enter your Student Id");
			userId = Integer.parseInt(br.readLine());

			System.out.println("Enter your date of Birth (dd/mm/yyyy)");
			SimpleDateFormat simpleFormat = new SimpleDateFormat("dd/mm/yyyy");
			String dateOfBirth = br.readLine().trim();
			dateBirth = simpleFormat.parse(dateOfBirth);

			System.out.println("Enter your BloodGroup");
			bloodGroup = br.readLine();

			System.out.println("Enter your Height(feet)");
			feet = Integer.parseInt(br.readLine());

			System.out.println("Enter your Height(inches)");
			inches = Integer.parseInt(br.readLine());

			System.out.println("Enter your Marks");
			marks = Integer.parseInt(br.readLine());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Student student = new Student();
		student.setName(name);
		student.setUserId(userId);
		student.setDateOfBirth(dateBirth);
		student.setBloodGroup(bloodGroup);
		Height height = new Height(feet, inches);
		student.setHeight(height);
		student.setMarks(marks);
		
		StudentDatabaseServices studentDatabaseServices = new StudentDatabaseServices();
		studentDatabaseServices.addStudent(student);

	}
}
