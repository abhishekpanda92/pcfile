package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.virtusa.model.Employee;
import com.virtusa.model.Student;


public class RegisteredUsersDetailsMain {

	public static final String EMPLOYEE_PATH = "EmployeeDb.txt";
	public static final String STUDENT_PATH = "StudentDb.txt";
	public static void main(String[] args) 

	{
		InputStreamReader is = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(is);
		System.out.println("Are you a Employee or a Student(E/S)");
		String category = null;
		try {
			category = br.readLine().toUpperCase();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (category.equals("E")) {
			System.out
					.println("Do You want to Add details or View Details(A/V)");
			try {
				category = br.readLine().toUpperCase();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (category.equals("A")) {
                    EmployeeDetailsMain employeeDetailsMain = new EmployeeDetailsMain();
                    employeeDetailsMain.getEmloyeeDetails();
				
			} else {
				
				Employee employee = new Employee();
				employee.displayDetails(EMPLOYEE_PATH);
			}
		} else {
			System.out
					.println("Do You want to Add details or View Details(A/V)");
			try {
				category = br.readLine().toUpperCase();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (category.equals("A")) {
				StudentDetailsMain studentDetailsMain = new StudentDetailsMain();
				studentDetailsMain.getStudentDetails();
			} else {
				Student student = new Student();
				student.displayDetails(STUDENT_PATH);
			}
		}

	}
}
