package com.virtusa.client;

import com.virtusa.polymorphism.Figure;
import com.virtusa.polymorphism.Rectangle;
import com.virtusa.polymorphism.Triangle;

public class CheckPolymorphism {

	public static void main(String[] args)
	{
		Figure f=new Figure(45,6);
		Rectangle r=new Rectangle(10,30);
		Triangle t=new Triangle(10,20);
		Figure a;
		a=f;
		System.out.println(a.area());
		a=r;
		System.out.println(a.area());
		a=t;
		System.out.println(a.area());
	}
}
