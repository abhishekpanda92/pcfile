package com.virtusa.polymorphism;

public class Rectangle extends Figure
{
	public Rectangle(double a,double b)
	{
		super(a,b);
	}
	public double area()
	{
		System.out.println("Area of rectangle");
		return d1*d2;
	}
}