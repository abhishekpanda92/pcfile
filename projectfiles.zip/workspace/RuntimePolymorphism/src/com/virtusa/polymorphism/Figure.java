package com.virtusa.polymorphism;

public class Figure {
	double d1, d2;

	public Figure(double a, double b) {
		d1 = a;
		d2 = b;
	}

	public double area() {
		System.out.println("Area of the figure");
		return 0;
	}
}
