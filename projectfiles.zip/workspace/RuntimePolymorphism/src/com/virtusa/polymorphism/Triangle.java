package com.virtusa.polymorphism;

public class Triangle extends Figure
{
	public Triangle(double a,double b)
	{
		super(a,b);	
	}
	public double area()
	{
		System.out.println("Area of triangle");
		return d1*d2/2;
	}
}