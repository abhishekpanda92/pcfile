package com.virtusa.client;

import com.virtusa.services.PhoneListServices;

public class PhoneListMain {

	public static void main(String [] args)
	{
		final PhoneListServices phoneListServices = new PhoneListServices();
		phoneListServices.add(9503370774L);
		phoneListServices.add(9503370775L);
		phoneListServices.add(9503370776L);
		phoneListServices.add(9503370777L);
		//phoneListServices.display();
		
		Thread normalOrder = new Thread(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				phoneListServices.display();
			}
			
		});
		
		normalOrder.start();
		
		
		Thread reverseOrder = new Thread(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				phoneListServices.displayReverse();
			}
			
		});
		
		reverseOrder.start();
		
	}
}
