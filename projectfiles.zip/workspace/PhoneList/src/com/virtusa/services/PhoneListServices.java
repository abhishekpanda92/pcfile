package com.virtusa.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PhoneListServices {

	private List<Long> phoneList = new ArrayList<Long>();

	public void add(Long phoneNo) {
		phoneList.add(phoneNo);
	}

	public void display() {
		System.out.println("Insertion Order: ");
		Iterator<Long> iterator = phoneList.iterator();
		while (iterator.hasNext()) {
			System.out.print(iterator.next() + " ");
		}

		System.out.println();
	}

	public void displayReverse() {
		System.out.println("Reversed: ");
		for (int i = phoneList.size() - 1; i >= 0; i--) {
			System.out.print(phoneList.get(i) + " ");
		}
	}
}
