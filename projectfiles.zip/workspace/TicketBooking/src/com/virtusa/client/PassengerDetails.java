package com.virtusa.client;

import java.util.Scanner;

import com.virtusa.services.CancelTicketServices;
import com.virtusa.services.PassengerDetailServices;

public class PassengerDetails {

	public static void main(String[] args)
	{

		System.out.println("Do you want to Book(B) or Cancel(C) a ticket");
		Scanner operation = new Scanner(System.in);
		String choice = operation.next();
		
		if(choice.equalsIgnoreCase("B"))
		{
			PassengerDetailServices passengerDetailServices = new PassengerDetailServices();
			passengerDetailServices.getPassengerDetails();
		}
		else if(choice.equalsIgnoreCase("C"))
		{
			System.out.println("Enter the PnrNo.");
			long pnrNo = operation.nextLong();
			CancelTicketServices cancelTicketServices = new CancelTicketServices();
			cancelTicketServices.cancel(pnrNo);
		}
		else
		{
			System.out.println("UnSupported Service.... Kindly reply with B(Book) or C(Cancel)");
		}
		
		operation.close();
	}
}
