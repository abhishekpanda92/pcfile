package com.virtusa.model;

import java.util.Date;

public class Ticket {

	
	private long pnrNo;
	private String origin;
	private String destination;
	private Date journeyDate;
	private String status;
	private int seatNo; // 0 in case the ticket is waitlisted
	
	public Ticket(long pnrNo,String origin,String destination,Date journeyDate, String status ,int seatNo)
	{
		this.pnrNo = pnrNo;
		this.origin = origin;
		this.destination = destination;
		this.journeyDate = journeyDate;
		this.status= status;
		this.seatNo = seatNo;
	}

	public long getPnrNo() {
		return pnrNo;
	}

	public void setPnrNo(long pnrNo) {
		this.pnrNo = pnrNo;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
	
}
