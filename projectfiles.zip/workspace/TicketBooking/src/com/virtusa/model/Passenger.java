package com.virtusa.model;

import java.io.Serializable;

public class Passenger implements Serializable {

	private String name;
	private int age;
	private String gender;
	private long contactNo;
	private String emaildId;
	private Ticket ticket;

	public Passenger(String name, int age, String gender, long contactNo,
			String emailId) {
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.contactNo = contactNo;
		this.emaildId = emailId;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getGender() {
		return gender;
	}

	public long getContactNo() {
		return contactNo;
	}

	public String getEmaildId() {
		return emaildId;
	}

	public void setTicketDetails(Ticket ticket) {
		this.ticket = ticket;
	}

	public Ticket getTicketDetails() {
		return ticket;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String passengerInfo = new String();
		passengerInfo += name + "-" + age + "-" + gender + "-" + contactNo
				+ "-" + emaildId + "-" + ticket.getOrigin() + "-"
				+ ticket.getDestination() + "-" + ticket.getPnrNo() + "-"
				+ ticket.getStatus() + "-" + ticket.getSeatNo();

		return passengerInfo;
	}
	

}
