package com.virtusa.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import com.virtusa.model.Passenger;
import com.virtusa.model.Ticket;

public class BookTicketServices {

	// List<Passenger> bookedPassengers = new ArrayList<Passenger>();
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);
	public final String booked = "Booked";
	public final String waitListed = "W/L";

	boolean status = true;

	public void journeyDetails(Passenger passenger) {
		// TODO Auto-generated method stub

		String sourceStation;
		String destinationStation;
		Date journeyDate = null;
		try {
			System.out.println("Enter the Source Station");
			sourceStation = br.readLine();

			System.out.println("Enter the Destination Station");
			destinationStation = br.readLine();

			System.out.println("Enter the Date of Journey Station(dd/MM/yyyy");

			String dateInput = br.readLine();
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

			try {
				journeyDate = dateFormat.parse(dateInput);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// System.out.println(dateFormat.format(date));
			book(passenger, sourceStation, destinationStation, journeyDate);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void book(Passenger passenger, String sourceStation,
			String destinationStation, Date journeyDate) {
		Ticket ticket = null;
		long pnrNo = 0;
		String ticketStatus = null;
		int seatNo = 0;

		File file = new File("c:\\database\\maxtickets.txt");
		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int availableSeats = 0;

		try {
			availableSeats = Integer.parseInt(br.readLine().trim());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (availableSeats > 0) {

			pnrNo = providePnrNo();
			seatNo = provideSeatNo();
			ticketStatus = booked;
			ticket = new Ticket(pnrNo, sourceStation, destinationStation,
					journeyDate, ticketStatus, seatNo);
			// br.close();

			PrintWriter fileWriter = null;
			try {
				fileWriter = new PrintWriter(new FileOutputStream(file, false));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			fileWriter.write(String.valueOf(--availableSeats));
			// fileWriter.println();
			fileWriter.close();

		} else {
			pnrNo = providePnrNo();
			seatNo = 0;
			ticketStatus = waitListed;
			ticket = new Ticket(pnrNo, sourceStation, destinationStation,
					journeyDate, ticketStatus, seatNo);
		}

		passenger.setTicketDetails(ticket);
		passengerDetailsAfterBooking(passenger);
		updateDb(passenger);
	}

	private void updateDb(Passenger passenger) {
		try {

			File file = new File("c:\\database\\passengerDetails.txt");

			PrintWriter fileWriter = new PrintWriter(new FileOutputStream(file,
					true));
			fileWriter.write(passenger.toString());
			fileWriter.println();
			fileWriter.close();

			file = new File("c:\\database\\PnrDatabase.txt");
			fileWriter = new PrintWriter(new FileOutputStream(file, true));
			fileWriter.write(String.valueOf(passenger.getTicketDetails()
					.getPnrNo()));
			fileWriter.println();
			fileWriter.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private int provideSeatNo() {
		// TODO Auto-generated method stub
		int seatNo = 0;
		File file = new File("c:\\database\\seatsOccupied.txt");
		PrintWriter fileWriter = null;
		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String seatsOccupied = null;
		try {
			seatsOccupied = br.readLine();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for (int i = 1; i < 73; i++) {
			if (!seatsOccupied.contains("," + String.valueOf(i) + ",")) {
				seatNo = i;
				try {
					fileWriter = new PrintWriter(new FileOutputStream(file,
							true));
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				fileWriter.write(String.valueOf(i) + ",");
				// fileWriter.println();
				fileWriter.close();
				break;
			}

		}

		return seatNo;
	}

	private long providePnrNo() {
		// TODO Auto-generated method stub

		long pnrNo = 9999999999l;
		while (status) {
			pnrNo = checkUniqueness();
		}
		return pnrNo;
	}

	private long checkUniqueness() {
		long pnrNo = (long) (1000000001 * Math.random());

		status = false;
		return pnrNo;
	}

	private void passengerDetailsAfterBooking(Passenger passenger) {
		System.out.println("Passenger Details After Booking");
		System.out.println("Name: " + passenger.getName() + "\n" + "Age: "
				+ passenger.getAge() + "\n" + "Gender: "
				+ passenger.getGender());
		System.out.println("ContactNo.: " + passenger.getContactNo() + "\n"
				+ "EmailId: " + passenger.getEmaildId());

		System.out.println("\n" + "Ticket Details");
		System.out.println("Source: "
				+ passenger.getTicketDetails().getOrigin() + " to "
				+ "Destination: "
				+ passenger.getTicketDetails().getDestination());
		System.out
				.println("Pnr No. : " + passenger.getTicketDetails().getPnrNo()
						+ "\n" + "TicketStatus: "
						+ passenger.getTicketDetails().getStatus() + "\n"
						+ "SeatNo.: "
						+ passenger.getTicketDetails().getSeatNo());
	}

}
