package com.virtusa.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.virtusa.model.Passenger;

public class PassengerDetailServices {
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);

	public void getPassengerDetails() {
		System.out.println("Please Enter your Details");

		try {
			System.out.println("Enter your Name");
			String passengerName = br.readLine();

			System.out.println("Enter your Age");
			int passengerAge = Integer.parseInt(br.readLine());

			System.out.println("Enter your Gender");
			String passengerGender = br.readLine();

			System.out.println("Enter your Contact No. ");
			long passengerContact = Long.parseLong(br.readLine());

			System.out.println("Enter your Email Id");
			String passengerEmailId = br.readLine();

			Passenger passenger = new Passenger(passengerName, passengerAge,
					passengerGender, passengerContact, passengerEmailId);
			BookTicketServices bookTicketServices = new BookTicketServices();
			bookTicketServices.journeyDetails(passenger);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
