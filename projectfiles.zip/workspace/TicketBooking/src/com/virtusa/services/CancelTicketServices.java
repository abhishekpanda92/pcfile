package com.virtusa.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class CancelTicketServices {

	private BufferedReader br;

	public void cancel(long pnrNo) {
		// TODO Auto-generated method stub
		File file = new File("c:\\database\\passengerDetails.txt");
		try {
			br = new BufferedReader(new FileReader(file));
			try {
				String detail = "abcd";
				while (detail != null) {
					detail = br.readLine();
					//System.out.println(detail);
					if (detail.split("-")[7].equals(String.valueOf(pnrNo))) {

						String oldStatus = "Booked";
						String newStatus = "Cancelled";

						int oldSeatNo = Integer.parseInt(detail.split("-")[9]);
						PrintWriter fileWriter = new PrintWriter(
								new FileOutputStream(file, true));

						detail = detail.replaceAll(oldStatus + "-" + oldSeatNo,
								newStatus + "-" + 0); 
						fileWriter.write(detail);

						fileWriter.close();
						updateFile(detail);
						break;
						
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void updateFile(String detail) throws IOException {
		// TODO Auto-generated method stub
		File file = new File("c:\\database\\passengerDetails.txt");
		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      PrintWriter pw = null;
		try {
			pw = new PrintWriter(new FileWriter(file),true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      
	      String line = null;
	 
	      //Read from the original file and write to the new 
	      //unless content matches data to be removed.
	      while ((line = br.readLine()) != null) {
	        
	        if (!line.trim().equals(detail)) {
	 
	          pw.println(line);
	          pw.flush();
	        }
	      }
	      pw.close();
	      br.close();
	}

}
