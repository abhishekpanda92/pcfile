package com.virtusa.model;

public class Employee {

	private int empId;
	private String empName;
	private String designation;
	private Salary salary;
	private Department dept;
	private Address address;
	private User user;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}


	public void setBasicSalary(double salary) {
		this.salary = new Salary(salary);
	}

	public void setDepartment(int dept_no, String dept_name, String location) {
		this.dept = new Department(dept_no, dept_name, location);
	}

	public String getDepartment() {
		String department_details = "department name " + ":"
				+ dept.getDeptName() + "\n" + "department no." + ":"
				+ dept.getDeptNo() + "\n" + "department location" + ":"
				+ dept.getLocation();
		return department_details;
	}

	public String getAddress() {
		String addr = "house no. " + ":" + address.gethNo() + "\n"
				+ "street name" + ":" + address.getStreetName() + "\n"
				+ "city name " + ":" + address.getCity() + "\n" + "pincode "
				+ ":" + address.getPinCode();
		return addr;
	}

	public void setAddress(String hNo, String streetName, String city,
			int pinCode) {
		this.address = new Address(hNo, streetName, city, pinCode);
	}

	public String getSalaryDetails() {
		// TODO Auto-generated method stub
		String salaryDetails = "BasicSalary " + ":" + salary.getBasicSalary() + "\n"
				+ "HRA " + ":" + salary.getHra() + "\n"
				+ "CA " + ":" + salary.getCa() + "\n" + "Provident Fund : " +salary.getPf()
			+ "\n" + "Professional Tax : " +salary.getPt() + "\n" + "Gross Salary : " +salary.getGrossSalary()
			+ "\n" + "Net Salary : " +salary.getNetSalary();
		return salaryDetails;
	}

}
