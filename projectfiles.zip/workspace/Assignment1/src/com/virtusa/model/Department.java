package com.virtusa.model;

public class Department {

	private int deptNo;
	private String deptname;
	private String location;

	public Department(int dept_no,String dept_name,String location)
	{
		this.deptname = dept_name;
		this.deptNo = dept_no;
		this.location = location;
	}

	public int getDeptNo() {
		return deptNo;
	}

	public String getDeptName() {
		return deptname;
	}

	public String getLocation() {
		return location;
	}
	
	
}
