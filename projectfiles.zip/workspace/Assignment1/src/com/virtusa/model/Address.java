package com.virtusa.model;

public class Address {

	 private String hNo;
	 private String streetName;
	 private String city;
	 private int pinCode;
	 
	 public Address(String hNo, String streetName,String city, int pinCode)
	 {
		 this.hNo = hNo;
		 this.streetName = streetName;
		 this.city = city;
		 this.pinCode = pinCode;
	 }

	public String gethNo() {
		return hNo;
	}

	public String getStreetName() {
		return streetName;
	}

	
	public String getCity() {
		return city;
	}
	
	public int getPinCode() {
		return pinCode;
	}
	 
	 
}
