package com.virtusa.model;

public class Salary {

	private double basicSalary; 
	private double hra;
	private double ca;
	public double getBasicSalary() {
		return basicSalary;
	}

	public double getHra() {
		return hra;
	}

	public double getCa() {
		return ca;
	}

	public double getPf() {
		return pf;
	}

	public double getPt() {
		return pt;
	}

	public double getGrossSalary() {
		return grossSalary;
	}

	public double getNetSalary() {
		return netSalary;
	}

	private double pf;
	private double pt;
	private double grossSalary;
	private double netSalary;
	
	public Salary(double basicSalary)
	{
		this.basicSalary = basicSalary;
		ca = 0.05*basicSalary;
		hra = 0.1*basicSalary;
		
		pf = 0.12*basicSalary;
		pt = 0.02*basicSalary;
		
		grossSalary = basicSalary + ca + hra + pf ;
		netSalary = grossSalary - pf - pt;
	}
}
