package com.virtusa.model;

public class User {

	private String firstName;
	private String secondName;
	private String emailId;
	private long phoneNo;

	public User(String firstName, String secondName, String emailId,
			long phoneNo) {
		this.firstName = firstName;
		this.secondName = secondName;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getSecondName() {
		return secondName;
	}

	public String getEmailid() {
		return emailId;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

}
