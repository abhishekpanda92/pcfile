package com.virtusa.services;

public class ValidateEmailandPhone {

	public boolean validate(String emailid, int phone_length) {
		if (emailid.split("@")[1].equals("virtusa.com") && phone_length == 10) {
			return true;
		} else {
			return false;
		}
	}
}
