package com.virtusa.services;

public class RegisterServices {

	public boolean registrationValidation(String user_name, String password,
			String password_trim) {

		if (user_name.length() > 4 && password.equals(password_trim)
				&& password.length() >= 6 && password.length() <= 12) {
			return true;
		} else {
			return false;
		}
	}
}
