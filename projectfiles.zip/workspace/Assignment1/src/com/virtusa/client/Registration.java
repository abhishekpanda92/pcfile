package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.virtusa.model.User;
import com.virtusa.services.RegisterServices;

public class Registration {

	public void register(User user)
	{
		
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		
		try {
			System.out.println("Enter your username");
			String user_name = br.readLine();
			
			System.out.println("Enter your password");
			String password = br.readLine();
			
			String password_trim = password.trim();
			
			RegisterServices reg = new RegisterServices();
			
			if(reg.registrationValidation(user_name, password, password_trim))
			{
				System.out.println("Greetings.... U have registered successfully");
				EmployeeDetails em = new EmployeeDetails();
				em.employee_info(user);
			}
			else
			{
				System.out.println("The username and password do not match the standards");
				System.out.println("Kindly enter the username and password again");
				register(user);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
