package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.virtusa.model.User;
import com.virtusa.services.ValidateEmailandPhone;

public class LoginDetailsMain {

	

	public static void main(String[] args) {

		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);

		try {
			System.out.println("Do not enter any blank details");
			
			System.out.println("Enter your First Name");
			String firstName = br.readLine().trim();

			System.out.println("Enter your Second Name");
			String secondName = br.readLine().trim();

			System.out.println("Enter your Emaild Id");
			String emailId = br.readLine().trim();

			System.out.println("Enter your Phoneno");
			long phoneNo = Long.parseLong(br.readLine().trim());

			int phone_length = String.valueOf(phoneNo).length();
			ValidateEmailandPhone validateEmailandPhone = new ValidateEmailandPhone();

			if (validateEmailandPhone.validate(emailId, phone_length)) {
				User user = new User(firstName,secondName,emailId,phoneNo);
				
				
				System.out.println("WELCOME");
				System.out.println("USER NAME: " + user.getFirstName() + " "
						+ user.getSecondName());
				System.out.println("USER_EMAIL ID: " + user.getEmailid());
				System.out.println("USER PHONE NO.: " + user.getPhoneNo());
				Registration new_user = new Registration();
				new_user.register(user);
			} else {
				System.out.println("Enter the details again...Invalid Phone or EmailId details");
				main(args);
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
