package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.virtusa.model.Employee;
import com.virtusa.model.User;

public class EmployeeDetails {

	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);
	boolean status = false;

	public void employee_info(User user) {

		System.out.println("Kindly enter the person details");

		Employee e1 = new Employee();

		// Enter Personal details
		personalDetails(e1,user);
		if (status) {
			// Enter Address details
			status = false;
			addressDetails(e1);

			if (status) {

				status = false;
				// Enter Department details
				departmentDetails(e1);

				if (status) {
					displayDetails(e1);
				} else {
					System.out
							.println("There is something wrong with the Department details...");
					System.out
							.println("I am afraid!! you have to enter them again");

					// Enter Department details
					departmentDetails(e1);

				}

			} else {
				System.out
						.println("There is something wrong with the Address details...");
				System.out
						.println("I am afraid!! you have to enter them again");

				// Enter Address details
				addressDetails(e1);
			}

		} else {
			System.out
					.println("There is something wrong with the Personal details...");
			System.out.println("I am afraid!! you have to enter them again");
			// Enter Personal details
			personalDetails(e1,user);
		}

	}

	public void displayDetails(Employee e1) {
		System.out.println("PERSONAL DETAILS");
		System.out.println("employee id : " + e1.getEmpId());
		System.out.println("employee name : " + e1.getEmpName());
		System.out.println("employee designation : " + e1.getDesignation());

		System.out.println("\n" + "SALARY DETAILS" + "\n"
				+ e1.getSalaryDetails());

		System.out.println("\n" + "ADDRESS DETAILS" + "\n" + e1.getAddress());
		System.out.println("\n" + "DEPARTMENT DETAILS" + "\n"
				+ e1.getDepartment());
	}

	public void personalDetails(Employee e1 ,User user) {
	
		try {
			System.out.println("Please Enter the EmpId");
			double basicSalary;
			int empId = Integer.parseInt(br.readLine().trim());
			e1.setEmpId(empId);

			e1.setEmpName(user.getFirstName()+ " "
					+ user.getSecondName());

			System.out.println("Please Enter your Designation");
			String emp_desig = br.readLine().trim();
			e1.setDesignation(emp_desig);

			System.out.println("Please Enter your Basic Salary");
			basicSalary = Double.parseDouble(br.readLine().trim());
			e1.setBasicSalary(basicSalary);
			status = true;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}

	}

	public void departmentDetails(Employee e1) {
		
		try {
			String depart_name;
			int depart_no;
			String location;
			System.out.println("Kindly enter the department  details");
			System.out.println("Please Enter your Department Name");

			depart_name = br.readLine().trim();

			System.out.println("Please Enter your Department No.");
			depart_no = Integer.parseInt(br.readLine().trim());

			System.out.println("Please Enter your Department Location");
			location = br.readLine().trim();

			e1.setDepartment(depart_no, depart_name, location);
			status = true;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
	}

	public void addressDetails(Employee e1) {
	
		try {
			System.out.println("Kindly enter the Address details");
			System.out.println("Please Enter your House No.");
			String hNo = br.readLine().trim();

			System.out.println("Please Enter your Street Name");
			String streetName = br.readLine().trim();

			System.out.println("Please Enter your City Name");
			String city = br.readLine().trim();

			System.out.println("Please Enter your PinCode");
			int pinCode = Integer.parseInt(br.readLine().trim());
			
			e1.setAddress(hNo, streetName, city, pinCode);
			status = true;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
	}
}
