import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class Serialization {

	public static void main(String args[]) throws Exception
	{
		Account acc1 = new Account(1001,"acc1",200.50);
		Account acc2 = new Account(1002,"acc2",202.50);
		Account acc6 = new Account(1006,"acc6",206.50);
		FileOutputStream fout = new FileOutputStream("C:\\database\\account.ser");
		ObjectOutputStream oOut = new ObjectOutputStream(fout);
		
		oOut.writeObject(acc1);
		oOut.writeObject(acc2);
		oOut.writeObject(acc6);
		oOut.close();
		
		FileInputStream fin = new FileInputStream("C:\\database\\account.ser"); //2 objects and 2 references
		ObjectInputStream oIn = new ObjectInputStream(fin);
		
		 acc1 = (Account) oIn.readObject();
		 acc2 = (Account) oIn.readObject();
	     acc6 = (Account) oIn.readObject();
		System.out.println(acc1);
		System.out.println(acc2);
		System.out.println(acc6);
		oIn.close();
		
		
	}
}
