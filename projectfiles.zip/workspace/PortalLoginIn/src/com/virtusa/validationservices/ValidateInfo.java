package com.virtusa.validationservices;

import com.virtusa.loginexception.InvalidCredentialsException;

public class ValidateInfo {

	public boolean validate(int userId, String password)
			throws InvalidCredentialsException {
		if (String.valueOf(userId).length() >= 5
				&& password.equals("1234qwer$")) {
			return true;
		} else {

			throw new InvalidCredentialsException(
					"The credentials do not match the actual info");

		}
	}
}
