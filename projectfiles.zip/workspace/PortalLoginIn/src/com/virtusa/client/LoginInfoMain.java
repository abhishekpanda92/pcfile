package com.virtusa.client;

import java.util.Scanner;

import com.virtusa.loginexception.InvalidCredentialsException;
import com.virtusa.validationservices.ValidateInfo;

public class LoginInfoMain {

	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your userId");
		int userId = scanner .nextInt();
		
		System.out.println("Enter your pasword");
		String password = scanner.next();
		
		ValidateInfo validateInfo = new ValidateInfo();
		try {
			if(validateInfo.validate(userId, password))
			{
				System.out.println("WELCOME TO THE PORTAL");
			}
		} catch (InvalidCredentialsException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
		
		scanner.close();
		
	}
}
