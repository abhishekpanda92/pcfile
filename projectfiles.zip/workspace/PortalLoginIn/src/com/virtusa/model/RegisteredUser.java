package com.virtusa.model;

public class RegisteredUser {

	private int userId;
	public final String password = "1234qwer$";
	

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
}
