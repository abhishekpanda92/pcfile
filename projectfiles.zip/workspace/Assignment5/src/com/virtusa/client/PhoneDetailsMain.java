package com.virtusa.client;

import java.util.Scanner;

import com.virtusa.services.PhoneListServices;

public class PhoneDetailsMain {

	public static void main(String[] args) {
		int condition = 5;
		PhoneListServices phoneListServices = new PhoneListServices();
		while (condition > 0) {
			condition--;
			System.out.println("Enter the phone no.s");
			Scanner scanner = new Scanner(System.in);
			Long phoneNo = scanner.nextLong();
			phoneListServices.addPhone(phoneNo);
		}

		phoneListServices.display();

	}
}
