package com.virtusa.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PhoneListServices {
	List<Long> phonelist = new ArrayList<>();
	
	
	public void addPhone(Long phoneNo)
	{
		phonelist.add(phoneNo);
	}
	
	public void display()
	{
		Iterator<Long> iterator = phonelist.iterator();
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
	}
}
