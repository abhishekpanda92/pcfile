package com.ericsson.services;

import com.ericsson.model.Account;

public class AccountOperations {

	public void withdraw(Account acc, int amount) {

		double present_balance = acc.getBalance();
		if (present_balance > amount) {
			acc.setBalance(present_balance - amount);
			System.out.println("U have withdrawn " + amount);
			System.out.println("Present balance is " + acc.getBalance());
		} else {
			System.out.println("Insufficient funds in yout account");
		}
	}

	public void deposit(Account acc, int amount) {
		double present_balance = acc.getBalance();
		present_balance += amount;
		acc.setBalance(present_balance);
		System.out.println("Present balance is " + acc.getBalance());
	}

	public void fundtransfer(Account source, Account target, int amount) {
		double balance_source = source.getBalance();
		
		System.out.println("Balance in source " + source.getBalance());
		System.out.println("Balance in target " + target.getBalance());
		
		if (balance_source > amount) {
			balance_source -= amount;
			double balance_target = target.getBalance() + amount;
			source.setBalance(balance_source);
			target.setBalance(balance_target);
			
			System.out.println("Balance in source " + source.getBalance());
			System.out.println("Balance in target " + target.getBalance());
		}
		else {
			System.out.println("Insufficient funds in yout account");
		}
	}

}
