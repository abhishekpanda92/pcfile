package com.ericsson.model;

public class Employee {

	private int empId;
	private String empName;
	private String designation;
	private double salary;
	private Address address;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public 	String getAddress() {
		String addr =  address.gethNo()+"\n"+address.getStreetName()+"\n"+address.getPinCode();
		return addr;
	}

	public void setAddress(String hNo, String streetName, int pinCode) {
		this.address = new Address(hNo, streetName, pinCode);
	}

}
