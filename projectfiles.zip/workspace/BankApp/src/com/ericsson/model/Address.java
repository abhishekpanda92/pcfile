package com.ericsson.model;

public class Address {

	 private String hNo;
	 private String streetName;
	 private int pinCode;
	 
	 public Address(String hNo, String streetName, int pinCode)
	 {
		 this.hNo = hNo;
		 this.streetName = streetName;
		 this.pinCode = pinCode;
	 }

	public String gethNo() {
		return hNo;
	}

	public String getStreetName() {
		return streetName;
	}

	public int getPinCode() {
		return pinCode;
	}
	 
	 
}
