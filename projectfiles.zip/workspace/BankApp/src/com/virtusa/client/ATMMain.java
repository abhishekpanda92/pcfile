package com.virtusa.client;

import com.ericsson.model.Account;
import com.ericsson.services.AccountOperations;

public class ATMMain {

	public static void main(String[] args) {
		
		Account acc1 = new Account();// without this no memory allocation
		acc1.setAccNo(1000);
		acc1.setAccName("account1");
		acc1.setBalance(50000);
		int amount = 5000;
		
		AccountOperations aop = new AccountOperations();
        aop.withdraw(acc1, amount);
        
        Account acc2 = new Account();
		acc2.setAccNo(1000);
		acc2.setAccName("account2");
		acc2.setBalance(30000);
		int amount_dp = 5000;
		
		aop.deposit(acc2, amount_dp);
		aop.deposit(acc1, amount_dp);
		aop.fundtransfer(acc1, acc2, 10000);
	}

}
