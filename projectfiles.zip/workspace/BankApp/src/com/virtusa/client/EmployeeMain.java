package com.virtusa.client;

import com.ericsson.model.Address;
import com.ericsson.model.Employee;

public class EmployeeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee emp1; // local variable
		emp1 = new Employee();

		emp1.setEmpId(1000);
		emp1.setEmpName("Abhishek Panda");
		emp1.setDesignation("Engineer-Technology");
		emp1.setSalary(10000);

		emp1.setAddress("GA-90","Niladrivihar",751021);
		
		System.out.println(emp1.getEmpId());
		System.out.println(emp1.getEmpName());
		System.out.println(emp1.getDesignation());
		System.out.println(emp1.getSalary());
		System.out.println(emp1.getAddress());
	}

}
