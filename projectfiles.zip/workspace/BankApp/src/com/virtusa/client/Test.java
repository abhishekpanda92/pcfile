package com.virtusa.client;

import java.util.Scanner;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("This message prints on to the screen");
		Scanner scanner = new Scanner(System.in);
		int $response = scanner.nextInt();
		System.out.println("The entered no. is " + $response);
		scanner.close();

	}

}
