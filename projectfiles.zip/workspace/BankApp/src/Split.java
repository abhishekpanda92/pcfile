
public class Split {

	
	public static void main(String[] args)
	{
		String test = "Abhishek-Panda";
		System.out.println(test.split("-")[1]);
		
	}
}
