package com.virtusa.client;

import com.virtusa.collectionservices.CollectionServices;

public class CountryCapitalMain {

	public static void main(String[] args)
	{
		CollectionServices collectionServices = new CollectionServices();
		collectionServices.add("India", "New Delhi");
		collectionServices.add("SriLanka","Colombo");
		collectionServices.add("Bangaldesh","Dhaka");
		collectionServices.add("England","London");
		collectionServices.add("Australia","Canberra");
		
		collectionServices.sortedCapitals();
		
	}
}
