package com.virtusa.collectionservices;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;


public class CollectionServices {

	private Map<String, String> capitalList = new HashMap<>();

	public void add(String country, String capital) {
		capitalList.put(country, capital);
	}

	public void sortedCapitals() {
//		List<String> list = new ArrayList<String>(capitalList.values());
//		Collections.sort(list);
//		
//		Set<String> set = new TreeSet<>(capitalList.keySet());
//		
//		System.out.println(set);
		
		    Set<Entry<String, String>> set = capitalList.entrySet();
	        List<Entry<String, String>> list = new ArrayList<Entry<String, String>>(set);
	        
	        Collections.sort( list, new Comparator<Map.Entry<String, String>>()
	        {
	            public int compare( Map.Entry<String, String> o1, Map.Entry<String, String> o2 )
	            {
	                return (o1.getValue()).compareTo( o2.getValue() );
	            }
	        } );
	        for(Entry<String, String> entry:list){
	            System.out.println(entry.getKey()+" ==== "+entry.getValue());
	        }
	
	}
}
