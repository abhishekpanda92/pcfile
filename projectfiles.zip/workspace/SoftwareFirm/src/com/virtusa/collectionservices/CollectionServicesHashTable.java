package com.virtusa.collectionservices;


import java.util.Hashtable;
import java.util.Map;




public class CollectionServicesHashTable {
	Map<String,Double> balanceSheets = new Hashtable<>();
	
	
	public void addBalanceSheet(String year , Double balance)
	{
		balanceSheets.put(year, balance);
	}
	
	public void getBalance(String year)
	{
		System.out.println(balanceSheets.get(year));
	}
}
