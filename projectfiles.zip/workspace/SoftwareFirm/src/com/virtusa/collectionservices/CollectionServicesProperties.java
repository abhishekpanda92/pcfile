package com.virtusa.collectionservices;


import java.util.Properties;

public class CollectionServicesProperties {
	Properties balanceSheets = new Properties();
	
	
	public void addBalanceSheet(String year , Double balance)
	{
		balanceSheets.put(year, String.valueOf(balance));
	}
	
	public void getBalance(String year)
	{
		System.out.println(balanceSheets.getProperty(year));
	}
}
