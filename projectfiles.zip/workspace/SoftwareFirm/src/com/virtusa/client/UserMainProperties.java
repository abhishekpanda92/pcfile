package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.virtusa.collectionservices.CollectionServicesProperties;

public class UserMainProperties {

	public static void main(String[] args)
	{
		int condition = 3;
		CollectionServicesProperties collectionServicesProperties = new  CollectionServicesProperties();		
		InputStreamReader is = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(is);
		while (condition>0) {
			condition--;
			
			//Scanner scanner = new Scanner(System.in);
			System.out.println("Enter the year");
			String year = null;
			Double balance = 0.0;
			try {
				year = br.readLine();
				System.out.println("Enter the balance");
				balance = Double.parseDouble(br.readLine().trim());
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			collectionServicesProperties.addBalanceSheet(year, balance);
			//scanner.close();
		}
		
		Scanner scanner1 = new Scanner(System.in);
		System.out.println("Enter the year for balance");
		String year = scanner1.next();
		collectionServicesProperties.getBalance(year);
		scanner1.close();
		
		
	}
}
