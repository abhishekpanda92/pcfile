package com.virtusa.model;

public class Employee {

	private int employeeCode;
	private String employeeName;
	private double employeeSalary;

	public Employee(int employeeCode, String employeeName, double employeeSalary) {
		// super();
		this.employeeCode = employeeCode;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}

	@Override
	public String toString() {
		return "Employee [EmployeeCode=" + employeeCode + ", EmployeeName="
				+ employeeName + ", EmployeeSalary=" + employeeSalary + "]";
	}

	public int getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(int employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
}
