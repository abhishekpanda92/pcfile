package com.virtusa.userdefinedexceptions;



public class AlreadyExistingEmployeeNumberException extends Exception {

	/**
	 * 
	 */
	private String message;
	private static final long serialVersionUID = 1L;

	public AlreadyExistingEmployeeNumberException(int empId) {
		// TODO Auto-generated constructor stub
		this.message = "AlreadyExistingEmployeeNumberException" +" Employee exists......." + empId;
			
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return message;
	}
}
