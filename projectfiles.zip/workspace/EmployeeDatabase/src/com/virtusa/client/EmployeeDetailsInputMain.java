package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.virtusa.model.Employee;
import com.virtusa.services.EmployeeDaoImplementation;
import com.virtusa.userdefinedexceptions.AlreadyExistingEmployeeNumberException;
import com.virtusa.userdefinedexceptions.InvalidEmployeeIDException;

public class EmployeeDetailsInputMain {

	private EmployeeDaoImplementation employeeDaoImplementation = new EmployeeDaoImplementation();
	private InputStreamReader inputStreamReader = new InputStreamReader(
			System.in);
	private BufferedReader bufferedReader = new BufferedReader(
			inputStreamReader);

	public void enterEmployeeDetails()
			throws AlreadyExistingEmployeeNumberException {

		int employeeId = 0;
		String name = null;
		double salary = 0.0;

		try {
			System.out.println("Enter your employeeId");
			employeeId = Integer.parseInt(bufferedReader.readLine());

			System.out.println("Enter your Name");
			name = bufferedReader.readLine();

			System.out.println("Enter your Salary");
			salary = Double.parseDouble(bufferedReader.readLine());
			Employee employee = new Employee(employeeId, name, salary);
			employeeDaoImplementation.insertEmployee(employee);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}

	}

	public void displayEmployeeDetails(int empId)
			throws InvalidEmployeeIDException {

		Employee result = employeeDaoImplementation.fetchEmployee(empId);
		if (result != null)
			System.out.println(result);
		else
			throw new InvalidEmployeeIDException(empId);

	}
}
