package com.virtusa.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.virtusa.model.Employee;
import com.virtusa.services.EmployeeDaoImplementation;
import com.virtusa.userdefinedexceptions.AlreadyExistingEmployeeNumberException;
import com.virtusa.userdefinedexceptions.InvalidEmployeeIDException;
import com.virtusa.userdefinedexceptions.UnSupportedServiceException;

public class EmployeeClient {

	public static void main(String[] args) throws UnSupportedServiceException {
		System.out.println(".........EMPLOYEE DATABASE.........");

		// Common Objects for all the operations
		InputStreamReader inputStreamReader = new InputStreamReader(System.in);
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		EmployeeDetailsInputMain employeeDetailsInputMain = new EmployeeDetailsInputMain();

		// 1 for employee creation and 2 for viewing employee details
		System.out
				.println("Do want to add employee(1) or view employee details(2)?");
		String response = null;
		try {
			response = bufferedReader.readLine();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			System.out.println(e2);
			
		}

		if (response.equals(String.valueOf(1))) {
			System.out.println("How many employee do you wish to add?");
			int condition = 1;
			try {
				condition = Integer.parseInt(bufferedReader.readLine());
			} catch (NumberFormatException | IOException e2) {
				// TODO Auto-generated catch block
				System.out.println(e2);
			}

			while (condition > 0) {
				condition--;
				try {
					employeeDetailsInputMain.enterEmployeeDetails();
				} catch (AlreadyExistingEmployeeNumberException e) {
					// TODO Auto-generated catch block
					System.err.println(e);
				}
			}

		}
		else if(response.equals(String.valueOf(2)))
		{
			System.out.println("Enter the empId for details");
			try {
				int empId = Integer.parseInt(bufferedReader.readLine());
				employeeDetailsInputMain.displayEmployeeDetails(empId);
				
			}  catch (NumberFormatException | IOException e2) {
				// TODO Auto-generated catch block
				System.out.println(e2);
			} catch (InvalidEmployeeIDException e) {
				// TODO Auto-generated catch block
				System.err.println(e);
			}
		}
		else		
		{
			throw new UnSupportedServiceException("UnSupportedServiceException..."+"Service not Supported");
		}
	}
}
