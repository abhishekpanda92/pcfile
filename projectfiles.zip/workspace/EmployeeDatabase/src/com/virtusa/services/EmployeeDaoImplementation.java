package com.virtusa.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.virtusa.databaseservices.OracleConnection;
import com.virtusa.model.Employee;
import com.virtusa.userdefinedexceptions.AlreadyExistingEmployeeNumberException;
import com.virtusa.userdefinedexceptions.InvalidEmployeeIDException;

public class EmployeeDaoImplementation implements EmployeeDao {

	private Connection connection = OracleConnection.getConnection();
	private CallableStatement callableStatement;
	private Statement statement;

	@Override
	public int insertEmployee(Employee employee)
			throws AlreadyExistingEmployeeNumberException {
		// TODO Auto-generated method stub

		if (fetchEmployee(employee.getEmployeeCode()) != null)
			throw new AlreadyExistingEmployeeNumberException(
					employee.getEmployeeCode());

		try {
			callableStatement = connection
					.prepareCall("{call insert_employee(?,?,?)}");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			callableStatement.setInt(1, employee.getEmployeeCode());
			callableStatement.setString(2, employee.getEmployeeName());
			callableStatement.setDouble(3, employee.getEmployeeSalary());

			boolean result = callableStatement.execute();
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 1;
	}

	@Override
	public Employee fetchEmployee(int empId) {
		// TODO Auto-generated method stub

		Employee employee = null;
		try {
			statement = connection.createStatement();
			String sql = ("SELECT * FROM EMPLOYEES where employeeId = " + empId);
			ResultSet rs = null;
			rs = statement.executeQuery(sql);

			
				if (rs.next()) {
					int employeeId = rs.getInt(1);
					String employeeName = rs.getString(2);
					double employeeSalary = rs.getDouble(3);
					employee = new Employee(employeeId, employeeName,
							employeeSalary);
					return employee;
				}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return employee;

	}

}
