package com.virtusa.services;

import com.virtusa.model.Employee;
import com.virtusa.userdefinedexceptions.AlreadyExistingEmployeeNumberException;
import com.virtusa.userdefinedexceptions.InvalidEmployeeIDException;

public interface EmployeeDao {
	public int insertEmployee(Employee employee)
			throws AlreadyExistingEmployeeNumberException;

	public Employee fetchEmployee(int empId) throws InvalidEmployeeIDException;
}
