
public class TravelCarMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Travel t = new Travel();
		t.setCar(new Car());
		Car c = t.getCar();
		c.move();
	}

}
