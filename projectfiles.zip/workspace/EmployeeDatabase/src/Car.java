
public class Car {

	public void move()
	{
		System.out.println("Car Moves...");
	}
}
