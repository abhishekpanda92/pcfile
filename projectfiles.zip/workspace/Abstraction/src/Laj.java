import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Laj {

  private static void printLines(String name, InputStream ins) throws Exception {
    String line = null;
    BufferedReader in = new BufferedReader(
        new InputStreamReader(ins));
    while ((line = in.readLine()) != null) {
        System.out.println(name + " " + line);
    }
  }

  private static void runProcess(String command) throws Exception {
    Process pro = Runtime.getRuntime().exec(command);
    printLines(command + " stdout:", pro.getInputStream());
    printLines(command + " stderr:", pro.getErrorStream());
    pro.waitFor();
    System.out.println(command + " exitValue() " + pro.exitValue());
  }

  public static void main(String[] args) {
    try {
    	System.out.println("cd C:\\"+"\\");
      runProcess("cd C:\\"+"\\");
      System.out.println("root done");
      runProcess("cd Users\\abhishekpa@virtusa.com\\workspace\\Abstraction\\src");
      runProcess("javac Teast.java");
      runProcess("java Teast");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}