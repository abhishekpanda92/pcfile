public class Test {


	public static void main(String[] args) {
		String s1 = new String("hello");
		String s2 = "hello";
		if (s1 == s2) {
			System.out.println("hjfjdsdh");
		}
	}

}
