//import java.io.FileNotFoundException;
//import java.io.PrintStream;
//import java.util.Date;
//import java.util.Scanner;
//import java.util.logging.ConsoleHandler;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//
//
//public class Log4jTest {
//
//	private  static Logger log = Logger.getLogger("Log4jTest");
//	final static Logger logger = Logger.getLogger(Log4jTest.class);
//	public static void main(String[] args) throws FileNotFoundException
//	{
//		//System.setOut(new PrintStream("user.log")); // redirect from the console to a file
//		
//		
//		//log.trace() , log.debug(),log.info() warn error fatal
//		
//		log.setLevel(Level.WARNING);
//		
//		//log.log(LEVEL., msg)
//		//log.info("User opened the website");
//		//Logger - abstract capture the info which is to be sent to other platforms , 
//		//appender - sends the data to the destinations
//		//layout - how you want to log the information formatting of data basically
//		//level - used to group your data into different categories
//		
//		//log.addAppender(new ConsoleAppender());
//		
//		//Multithreaded environment system.out.println has draw backs
//		//System.out.println("User opened the website");
//	
//		
////		Scanner scanner = new Scanner(System.in);
////		log.info("Enter user name");
////		String username = scanner.next();
////		log.info("User entered the username"+ new Date().getDate());
////		
////		log.info("Enter user password");
////		String password = scanner.next();
////		log.info("User entered the password"+ new Date().getDate());
////		scanner.close();
////		
////		if(username.equals("user1") && password.equals("virtusa123") )
////		{
////			log.info("User logged into the system");
////		}
////		else
////		{
////			log.info("user login failed");
////		}
//	}
//}
