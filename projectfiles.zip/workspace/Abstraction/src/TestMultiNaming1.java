public class TestMultiNaming1 extends Thread{  
  public void run(){  
   System.out.println("running..."+currentThread().getName());  
   
  }  
 public static void main(String args[]) throws InterruptedException{  
  TestMultiNaming1 t1=new TestMultiNaming1();  
  TestMultiNaming1 t2=new TestMultiNaming1();  
//  System.out.println("Name of t1:"+t1.getName());  
//  System.out.println("Name of t2:"+t2.getName());  
//  
  t1.start();
 
  t1.join();
  t1.setName("Sonoo Jaiswal");
  t2.start();  
  
  
  System.out.println("After changing name of t1:"+t1.getName());  
 }  
}  