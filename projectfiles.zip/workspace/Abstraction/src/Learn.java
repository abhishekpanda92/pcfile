
public class Learn implements Cloneable {

	private static Learn learn = new Learn();
	int count;
	String s1="Welcome";  
	public static Learn getInstance()
	{
		return learn;
		
	}
	private Learn()
	{
		System.out.println("....Learn object created....");
	}

	public void  increaseCount()
	{
		count++;
		System.out.println(count);
	}
	
	  
	public Object clone()throws CloneNotSupportedException{  
	return super.clone();  
	}  
	
}
