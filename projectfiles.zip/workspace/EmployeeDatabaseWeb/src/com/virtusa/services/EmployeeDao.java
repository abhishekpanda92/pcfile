package com.virtusa.services;

import java.util.ArrayList;

import com.virtusa.model.Employee;
import com.virtusa.userdefinedexceptions.AlreadyExistingEmployeeNumberException;
import com.virtusa.userdefinedexceptions.InvalidEmployeeIDException;

public interface EmployeeDao {
	public int insertEmployee(Employee employee)
			throws AlreadyExistingEmployeeNumberException;

	public int removeEmployee(int empId)
			throws InvalidEmployeeIDException;
	public Employee fetchEmployee(int empId) throws InvalidEmployeeIDException;
	public ArrayList fetchEmployeeIds();
}
