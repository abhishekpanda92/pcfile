package com.virtusa.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.databaseservices.OracleConnection;
import com.virtusa.model.Employee;
import com.virtusa.userdefinedexceptions.AlreadyExistingEmployeeNumberException;
import com.virtusa.userdefinedexceptions.InvalidEmployeeIDException;

public class EmployeeDaoImplementation implements EmployeeDao {

	private Connection connection = OracleConnection.getConnection();
	private CallableStatement callableStatement;
	private Statement statement;
	private List<Integer> idList = new ArrayList<Integer>();
	private List<Employee> employeeList = new ArrayList<Employee>();

	@Override
	public int insertEmployee(Employee employee)
			throws AlreadyExistingEmployeeNumberException {
		// TODO Auto-generated method stub

		if (fetchEmployee(employee.getEmployeeCode()) != null)
			throw new AlreadyExistingEmployeeNumberException(
					employee.getEmployeeCode());

		try {
			callableStatement = connection
					.prepareCall("{call insert_employeee(?,?,?,?,?)}");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			callableStatement.setInt(1, employee.getEmployeeCode());
			callableStatement.setString(2, employee.getPassword());
			callableStatement.setString(3, employee.getEmployeeName());
			callableStatement.setDouble(4, employee.getEmployeeSalary());
			callableStatement.setInt(5, employee.getDepartmendId());

			boolean result = callableStatement.execute();
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 1;
	}

	@Override
	public Employee fetchEmployee(int empId) {
		// TODO Auto-generated method stub

		Employee employee = null;
		try {
			statement = connection.createStatement();
			String sql = ("SELECT * FROM EMPLOYEEDB where empId = " + empId);
			ResultSet rs = null;
			rs = statement.executeQuery(sql);

			
				if (rs.next()) {
					int employeeId = rs.getInt(1);
					String employeeName = rs.getString(2);
					String password = rs.getString(3);
					double employeeSalary = rs.getDouble(4);
					int deptId = rs.getInt(5);
					employee = new Employee(employeeId,password,employeeName,
							employeeSalary,deptId);
					return employee;
				}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return employee;

	}

	
	public Employee fetchEmployee(String  name) {
		// TODO Auto-generated method stub

		Employee employee = null;
		try {
			statement = connection.createStatement();
			String sql = ("SELECT * FROM EMPLOYEEDB where empname = \'" + name+"\'");
			System.out.println(sql);
			ResultSet rs  = statement.executeQuery(sql);
			System.out.println("query done..");


				if (rs.next()) {
					System.out.println("inside resultset");
					int employeeId = rs.getInt(1);
					String employeeName = rs.getString(3);
					String password = rs.getString(2);
					double employeeSalary = rs.getDouble(4);
					int deptId = rs.getInt(5);
					employee = new Employee(employeeId,password,employeeName,
							employeeSalary,deptId);
					return employee;
				}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return employee;

	}
	@Override
	public int removeEmployee(int empId) throws InvalidEmployeeIDException {
		// TODO Auto-generated method stub
		try {
			statement = connection.createStatement();
			String sql = ("delete FROM EMPLOYEEDB where empId = " + empId);
			statement.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new InvalidEmployeeIDException(empId);
		}


		return 0;
	}

	@Override
	public ArrayList<Integer> fetchEmployeeIds() {
		// TODO Auto-generated method stub
		try {
			statement = connection.createStatement();
			String sql = ("select empID FROM EMPLOYEEDB");
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next())
			{
				idList.add(rs.getInt(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
		return   (ArrayList<Integer>) idList;
	}
	
	public  int updatePassword(String password,int empId)
	{


		try {
			String sql = "update employeedb set password = "+ "'"+password+"'" +"where empid = "+empId;
			statement = connection.createStatement();
			int x = statement.executeUpdate(sql);
			System.out.println("rows updated "+x);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}
	
	public  int updateSalary(double salary,int empId)
	{

		try {
			String sql = "update employeedb set empsalary = "+ "'"+salary+"'" +"where empid = "+empId;
			statement = connection.createStatement();
			int x = statement.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}
	
	public  int updateEmpDept(int dept,int empId)
	{

		try {
			String sql = "update employeedb set deptid = "+ "'"+dept+"'" +"where empid = "+empId;
			statement = connection.createStatement();
			int x = statement.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}
	
	public  List<Employee> getEmployees()
	{

		Employee employee = null;
		try {
			String sql = "select * from employeedb";
			statement = connection.createStatement();
			ResultSet rs  = statement.executeQuery(sql);
			
			while(rs.next())
			{
				int employeeId = rs.getInt(1);
				String employeeName = rs.getString(3);
				String password = rs.getString(2);
				double employeeSalary = rs.getDouble(4);
				int deptId = rs.getInt(5);
				employee = new Employee(employeeId,password,employeeName,
						employeeSalary,deptId);
				employeeList.add(employee);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return employeeList;
	}
	
	

}
