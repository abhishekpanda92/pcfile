package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.services.EmployeeDaoImplementation;

/**
 * Servlet implementation class UpdateEmployeeInfo
 */
@WebServlet("/UpdateEmployeeInfo")
public class UpdateEmployeeInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	EmployeeDaoImplementation employeeDaoImplementation = new EmployeeDaoImplementation();

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		boolean status = false;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		Integer id = (Integer) session.getAttribute("id");
		
		String password = null;
		if (request.getParameter("emppassword").length() > 0) {
			password = request.getParameter("emppassword");
			employeeDaoImplementation.updatePassword(password,id);
			status = true;
		}
		double salary = 0.0;
		if ((request.getParameter("empsalary")).length() > 0) {
			salary = Double.parseDouble(request.getParameter("empsalary"));
			employeeDaoImplementation.updateSalary(salary,id);
			status = true;
		}

		int dept = 0;

		if ((request.getParameter("empdeptid").length() > 0)) {
			dept = Integer.parseInt(request.getParameter("empdeptid"));
			employeeDaoImplementation.updateEmpDept(dept,id);
			status = true;
		}
		
		if (status) {
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Employee Updation</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("Employee data updated to the database");
			//out.println("UserName = "+session.getValue("user"));
			out.println("</body>");
			out.println("</html>");
		}
		else
		{
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Employee Updation</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("Updation unsuccessfull");
			out.println("</body>");
			out.println("</html>");
		}

	}

}
