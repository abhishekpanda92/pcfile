package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.services.EmployeeDaoImplementation;

/**
 * Servlet implementation class EmployeeIdServletUpdate
 */
@WebServlet("/EmployeeIdServletUpdate")
public class EmployeeIdServletUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Employee Id List</title>");
		out.println("</head>");
		out.println("<body>");

		
		out.println("<form action="+"\"EmployeeUpdateServlet\""+"method ="+"\"post\"");
		out.println("<p>");

		
		EmployeeDaoImplementation employeeDaoImplementation = new EmployeeDaoImplementation();
		ArrayList<Integer> list = employeeDaoImplementation.fetchEmployeeIds();
		String cat = "\"cat\"";
		out.println("<select name ="+cat+">");
		for(Integer i : list)
		{

	          String empid=""+i;
	          out.println(" "+empid);
	      	     
	          out.println("<option "+"value = "+empid+">"+empid+"</option>");
	         // out.println("<input type='checkbox' name= '"+"id"+"'"+"value = "+empid+">");
	        //  out.println("<br/>");

	         
		}
        out.println("</select>");
		out.println("</p>");
        out.println("<input type='submit' name='"+"submit"+"' text='"+"submit"+"'>");
    	out.println("</form>");	
		out.println("</body>");
		out.println("</html>");	
	 
		
	}

}
