package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.model.Employee;
import com.virtusa.services.EmployeeDaoImplementation;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("uname");

		String password = request.getParameter("password");

		HttpSession session = request.getSession();
		session.setAttribute("user", username); // vALUES can be any java object
		session.setAttribute("password", password);

		EmployeeDaoImplementation employeeDaoImplementation = new EmployeeDaoImplementation();
		Employee resultEmployee = employeeDaoImplementation
				.fetchEmployee(username);
		
		System.out.println("employeesalart: "+resultEmployee.getEmployeeSalary());

		System.out.println("password: "+password);
		System.out.println("password: "+resultEmployee.getPassword());
		if (resultEmployee != null
				&& resultEmployee.getPassword().trim().equals(password.trim())
				&& resultEmployee.getDepartmendId() == 1) {
			out.println("<html>");
			out.println("<head>");
			out.println("<title>USER ID</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("USERNAME: "+username.toUpperCase());
			out.println("</body>");
			out.println("</html>");
			RequestDispatcher requestDispatcher =
				    request.getRequestDispatcher("HrHomePagehtml.html");
			requestDispatcher.include(request, response);
		} else if (resultEmployee != null
				&& resultEmployee.getPassword().equals(password)
				&& resultEmployee.getDepartmendId() != 1) {
			out.println("<html>");
			out.println("<head>");
			out.println("<title>DEVELOPERS HOME PAGE</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("Under Construction....");
			out.println("</body>");
			out.println("</html>");
		} else {
			response.sendRedirect("login.html");
		}

	}

}
