package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.services.EmployeeDaoImplementation;
import com.virtusa.userdefinedexceptions.InvalidEmployeeIDException;

/**
 * Servlet implementation class EmployeeDeleteServlet
 */
@WebServlet("/EmployeeDeleteServlet")
public class EmployeeDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("inside the new servlet");
		String category = request.getParameter("cat");
		System.out.println("CATEGORY: "+category);
		int id = Integer.parseInt(category);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		EmployeeDaoImplementation employeeDaoImplementation = new EmployeeDaoImplementation();
		try {
			employeeDaoImplementation.removeEmployee(id);
			out.println("<html>");
			out.println("<head>");
			out.println("<title>DELETE EMPLOYEE</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("Deleted Successfully....");
			out.println("</body>");
			out.println("</html>");
		} catch (InvalidEmployeeIDException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
