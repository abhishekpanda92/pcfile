package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.model.Employee;
import com.virtusa.services.EmployeeDaoImplementation;
import com.virtusa.userdefinedexceptions.AlreadyExistingEmployeeNumberException;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeDatabase")
public class EmployeeAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int empCode = 0;
		String empName = null;
		double empSalary = 0.0;
		String empPassword = null;
		int deptId = 0;
		try {
			empCode = Integer.parseInt(request.getParameter("empcode"));
			empName = request.getParameter("empname");
			empSalary = Double.parseDouble(request.getParameter("empsalary"));
			empPassword = request.getParameter("emppassword");
			deptId = Integer.parseInt(request.getParameter("empdeptid"));
			Employee employee = new Employee(empCode,empPassword,empName, empSalary,deptId);
			EmployeeDaoImplementation employeeDaoImplementation = new EmployeeDaoImplementation();
			try {
				employeeDaoImplementation.insertEmployee(employee);
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Employee Database</title>");
				out.println("</head>");
				out.println("<body>");
				out.println("Employee added to the database");
				out.println("</body>");
				out.println("</html>");
			} catch (AlreadyExistingEmployeeNumberException e) {
				// TODO Auto-generated catch block
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Employee Database</title>");
				out.println("</head>");
				out.println("<body>");
				out.println("The Employee already Exists");
				out.println("</body>");
				out.println("</html>");
			}

		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			out.println("<html>");
			out.println("<head>");
			out.println("<title>NumberFormatException</title>");
			out.println("</head>");
			out.println("<body>");
			out.println(e1);
			out.println("</body>");
			out.println("</html>");
		}

	}

}
