package com.virtusa.model;

public class Employee {

	private int employeeCode;
	private String employeeName;
	private String password;
	private double employeeSalary;
	private int departmentId;
	public Employee(int employeeCode,  String password,String employeeName,
			double employeeSalary, int departmentId) {
		//super();
		this.employeeCode = employeeCode;
		this.employeeName = employeeName;
		this.password = password;
		this.employeeSalary = employeeSalary;
		this.departmentId = departmentId;
	}
	public int getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(int employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public int getDepartmendId() {
		return departmentId;
	}
	public void setDepartmendId(int departmentId) {
		this.departmentId = departmentId;
	}

	@Override
	public String toString() {
		return "Employee [employeeCode=" + employeeCode + ", employeeName="
				+ employeeName + ", password=" + password + ", employeeSalary="
				+ employeeSalary + ", departmendId=" + departmentId + "]";
	}

	
}
