package com.virtusa.services;

import java.io.File;

public class FileSearchServices {

	private final String ROOT = "C:\\Users\\abhishekpa@virtusa.com\\Downloads";
	private String root;
	private String fileName;
	private boolean status = false;

	public FileSearchServices() {
		this.root = ROOT;
	}

	public boolean searchForFile(String fileName) {
		this.fileName = fileName;
		//this.root = root;
		search(root);
		return status;

	}

	private void search(String path) {
		File file = new File(path);
		File[] fileList = file.listFiles();

		for (int i = 0; i < fileList.length; i++) {
			if (fileList[i].isFile()) {
				if (fileList[i].getName().equals(fileName)) {
					status = true;
					return;
				}
			} else {
				search(fileList[i].getAbsolutePath());
			}
		}

	}

}
