package com.virtusa.services;

import java.io.File;

public class DirectoryFileNameServices {


	public void search(String path) {
		System.out.println("PATH: "+path);
		File file = new File(path);
		File[] fileList = file.listFiles();

		for (int i = 0; i < fileList.length; i++) {
			if (fileList[i].isFile()) {
				System.out.println("FileName: " + fileList[i].getName());
			} else {
				System.out.println("DirectoryName: " + fileList[i].getName());
				search(fileList[i].getAbsolutePath());
			}
		}

	}

}
