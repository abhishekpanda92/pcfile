package com.virtusa.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import com.virtusa.services.DirectoryFileNameServices;

public class FileDirectoryNamesMain {

	public static void main(String[] args) {
		InputStreamReader is = new InputStreamReader(System.in);
		BufferedReader bufferedReader = new BufferedReader(is);
		String directory = null;
		try {
			directory = bufferedReader.readLine().toString();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		File file = new File(directory);
		if (file.exists()) {
			DirectoryFileNameServices DirectoryFileNameServices = new DirectoryFileNameServices();
			DirectoryFileNameServices.search(file.getAbsolutePath());
		}
	}
}
