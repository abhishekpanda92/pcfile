package com.virtusa.client;

import java.util.Scanner;

import com.virtusa.services.FileSearchServices;

public class FileSearchMain {

	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		FileSearchServices  fileSearchServices = new FileSearchServices();
		String fileName = scanner.next().trim();
		scanner.close();
		System.out.println(fileSearchServices.searchForFile(fileName));
		
	}
}
