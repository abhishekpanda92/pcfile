
public class CollectionsDemo
{
	public static void main(String[] args)
	{
		String name = "ABHISHEK";
		String name2 = name;
		
		if(name.equals(name2))
		{
			System.out.println("equals");
		}
	  
		if(name2 == name)
		{
			System.out.println("=");
		}
		
		
	}
}