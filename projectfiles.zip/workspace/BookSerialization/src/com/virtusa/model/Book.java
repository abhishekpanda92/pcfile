package com.virtusa.model;

import java.io.Serializable;

public class Book implements Serializable {

	private String bookTitle;
	private String authorName;
	private double price;

	public Book() {

	}

	public Book(String bookTitle, String authorName, double price) {
		this.bookTitle = bookTitle;
		this.authorName = authorName;
		this.price = price;

	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Book [bookTitle=" + bookTitle + ", authorName=" + authorName
				+ ", price=" + price + "]";
	}

}
