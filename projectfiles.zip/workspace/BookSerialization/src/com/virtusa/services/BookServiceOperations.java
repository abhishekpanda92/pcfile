package com.virtusa.services;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.model.Book;

public class BookServiceOperations {

	List<Book> bookList = new ArrayList<>();

	public void addBooks(Book book) {

		bookList.add(book);
	}

	public Book searchForBookByAuthor(String author) throws IOException,
			ClassNotFoundException {
		FileInputStream fin = new FileInputStream("C:\\database\\books.ser");

		ObjectInputStream oIn = new ObjectInputStream(fin);
		ArrayList<Book> bookListSaved = (ArrayList<Book>) oIn.readObject();
		Book book = new Book();
		
		for (int i = 0; i < bookListSaved.size(); i++) {
			if (bookListSaved.get(i).getAuthorName().equals(author)) {
				book = bookListSaved.get(i);
				fin.close();
				oIn.close();
				return book;
			}
		}

		fin.close();
		return book;

	}

	public void saveArrayList() throws IOException {
		FileOutputStream fout = new FileOutputStream("C:\\database\\books.ser");
		ObjectOutputStream oOut = new ObjectOutputStream(fout);

		oOut.writeObject(bookList);

		oOut.close();
	}
}
