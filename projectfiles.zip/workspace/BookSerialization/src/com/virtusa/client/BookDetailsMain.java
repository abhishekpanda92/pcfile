package com.virtusa.client;


import java.io.IOException;


import com.virtusa.model.Book;
import com.virtusa.services.BookServiceOperations;

public class BookDetailsMain {

	public static void main(String[] args) {

//		InputStreamReader is = new InputStreamReader(System.in);
//		BufferedReader br = new BufferedReader(is);
		BookServiceOperations bookServicesOperations = new BookServiceOperations();

		Book book = new Book("2 States", "Chetan Bhagat", 25.0);
		Book book1 = new Book("3 States", "Chetan Bhagat2", 125.0);
		Book book2 = new Book("4 States", "Chetan Bhagat3", 225.0);
		Book book3 = new Book("5 States", "Chetan Bhagat4", 325.0);


			bookServicesOperations.addBooks(book);
			bookServicesOperations.addBooks(book1);
			bookServicesOperations.addBooks(book2);
			bookServicesOperations.addBooks(book3);
			try {
				bookServicesOperations.saveArrayList();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		
		try {
			book = bookServicesOperations.searchForBookByAuthor("Chetan Bhagat");
			System.out.println(book);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
