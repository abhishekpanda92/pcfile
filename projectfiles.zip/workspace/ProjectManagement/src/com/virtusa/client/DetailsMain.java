package com.virtusa.client;

import java.text.ParseException;

import com.virtusa.collection.CollectionOperations;

public class DetailsMain {

	public static void main(String[] args) {
		CollectionOperations collectionOperations = new CollectionOperations();
		try {
			collectionOperations.updateCollection();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		collectionOperations.displayDetails();
	}
}
