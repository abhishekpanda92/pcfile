package com.virtusa.model;

import java.util.Date;

public class Project implements Comparable<Project> {

	private int projId;
	private String projName;
	private Date projStartDate;
	private Date projEndDate;
	private long projBudget;
	private String projManagerName;
	private String projManagerUnit;

	public Project() {

	}

	@Override
	public String toString() {
		return "Project [projId = " + projId + ", projName = " + projName
				+ ", projStartDate = " + projStartDate + ", projEndDate = "
				+ projEndDate + ", projBudget = " + projBudget
				+ ", projManagerName = " + projManagerName
				+ ", projManagerUnit = " + projManagerUnit + "]";
	}

	public Project(int projId, String projName, Date projStartDate,
			Date projEndDate, long projBudget, String projManagerName,
			String projManagerUnit) {
		this.projId = projId;
		this.projName = projName;
		this.projStartDate = projStartDate;
		this.projEndDate = projEndDate;
		this.projBudget = projBudget;
		this.projManagerName = projManagerName;
		this.projManagerUnit = projManagerUnit;
	}

	public int getProjId() {
		return projId;
	}

	public void setProjId(int projId) {
		this.projId = projId;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public Date getProjStartDate() {
		return projStartDate;
	}

	public void setProjStartDate(Date projStartDate) {
		this.projStartDate = projStartDate;
	}

	public Date getProjEndDate() {
		return projEndDate;
	}

	public void setProjEndDate(Date projEndDate) {
		this.projEndDate = projEndDate;
	}

	public long getProjBudget() {
		return projBudget;
	}

	public void setProjBudget(long projBudget) {
		this.projBudget = projBudget;
	}

	public String getProjManagerName() {
		return projManagerName;
	}

	public void setProjManagerName(String projManagerName) {
		this.projManagerName = projManagerName;
	}

	public String getProjManagerUnit() {
		return projManagerUnit;
	}

	public void setProjManagerUnit(String projManagerUnit) {
		this.projManagerUnit = projManagerUnit;
	}

	@Override
	public int compareTo(Project arg0) {
		// TODO Auto-generated method stub
		return this.projName.compareTo(arg0.projName);
	}

}
