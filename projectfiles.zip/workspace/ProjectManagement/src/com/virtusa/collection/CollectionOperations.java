package com.virtusa.collection;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.virtusa.model.Project;

public class CollectionOperations {

	List<Project> projects = new ArrayList<>();
	SimpleDateFormat simpleFormat = new SimpleDateFormat("dd/mm/yyyy");
    private static final int IterationsConstant = 5;
	
	
	public void updateCollection() throws ParseException {
		for (int i = 0; i < IterationsConstant; i++) {
			Project project = new Project(100 + i, "project " + (i+1),
					simpleFormat.parse("1" + i + "/03/2015"),
					simpleFormat.parse("2" + i + "/03/2015"), (i + 1) * 10000,
					"MANAGER " + (i + 1), "Unit " + (i + 1));
			projects.add(project);
		}
	}

	public void displayDetails() {
		Iterator<Project> iterator = projects.iterator();
		while (iterator.hasNext()) {
			Project project = iterator.next();
			System.out.println(project);
		}
	}
}
