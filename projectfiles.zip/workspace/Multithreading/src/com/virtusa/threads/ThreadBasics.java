package com.virtusa.threads;

public class ThreadBasics implements Runnable {

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		for (int i = 100; i > 0; i--) {
			System.out.println("ThreadBasics instance: "+i);
		}

	}

}
