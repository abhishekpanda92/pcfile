package com.virtusa.threads;

public class ExtendThreadClass extends Thread {

	public void run()
	{
		for(int i = 1; i<100; i++)
		{
			System.out.println("extendThreadClass instance "+i);
		}
	}
	
	
	public static void main(String[] args)
	{
		ExtendThreadClass extendThreadClass = new ExtendThreadClass();
		extendThreadClass.start();
		
		ThreadBasics threadBasics = new ThreadBasics();
		Thread t = new Thread(threadBasics);
		t.start();
		
	}
}
