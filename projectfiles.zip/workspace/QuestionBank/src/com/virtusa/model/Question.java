package com.virtusa.model;

import java.io.Serializable;

public class Question implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String quesTitle;
	private String ques;
	private String createdBy;

	public String getQuesTitle() {
		return quesTitle;
	}

	public void setQuesTitle(String quesTitle) {
		this.quesTitle = quesTitle;
	}

	public String getQues() {
		return ques;
	}

	public void setQues(String ques) {
		this.ques = ques;
	}

	@Override
	public String toString() {
		return "QuestionBank [quesTitle=" + quesTitle + ", ques=" + ques
				+ ", createdBy=" + createdBy +"]";
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Question() {

	}
	
	public Question(String quesTitle, String ques, String createdBy) {
		this.quesTitle = quesTitle;
		this.ques = ques;
		this.createdBy = createdBy;
	}

	

}
