package com.virtusa.client;

import java.io.IOException;

import com.virtusa.model.Question;
import com.virtusa.services.QuestionServices;

public class QuestionBankMain {

	public static void main(String [] args)
	{
		Question ques = new Question("Maths","5*5","Abhishek");
		Question ques1 = new Question("Cricket","Greatest Cricketer","Sachin");
		Question ques2 = new Question("Politics","Greatest Politician","Narendra Modi");
		
		QuestionServices questionServices = new QuestionServices();
		questionServices.addQuestion(ques);
		questionServices.addQuestion(ques1);
		questionServices.addQuestion(ques2);
		
		try {
			questionServices.saveQuestions();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			ques = questionServices.retrieveUsersByAuthor("Abhishek");
			System.out.println(ques);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
