package com.virtusa.services;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.model.Question;

public class QuestionServices {

	List<Question> quesList = new ArrayList<>();

	public void addQuestion(Question ques) {
		quesList.add(ques);
	}
	
	public void  saveQuestions() throws IOException 
	{
		FileOutputStream fout = new FileOutputStream("C:\\database\\question.ser");
		ObjectOutputStream oOut = new ObjectOutputStream(fout);

		oOut.writeObject(quesList);

		oOut.close();

	}
	
	public Question retrieveUsersByAuthor(String createdBy) throws ClassNotFoundException, IOException
	{
		FileInputStream fin = new FileInputStream("C:\\database\\question.ser");

		ObjectInputStream oIn = new ObjectInputStream(fin);
		ArrayList<Question> quesListSaved = (ArrayList<Question>) oIn.readObject();
		Question ques = new Question();
		
		for (int i = 0; i < quesListSaved.size(); i++) {
			if (quesListSaved.get(i).getCreatedBy().equals(createdBy)) {
				ques = quesListSaved.get(i);
				fin.close();
				oIn.close();
				return ques;
			}
		}

		fin.close();
		return ques;
	}
}