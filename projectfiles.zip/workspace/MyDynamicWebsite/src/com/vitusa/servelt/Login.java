package com.vitusa.servelt;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class Login extends GenericServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void Service(ServletRequest request,
			ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub


	}

	@Override
	public void service(ServletRequest request, ServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("uname");
		String password = request.getParameter("password");
		//((HttpServletRequest)request).geth

		if (username.equals("virtusa") && password.equals("123")) {
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Login Page</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("username = " + username + " " + "password = "
					+ password);
			out.println("</body>");
			out.println("</html>");
		}

		else {
//			out.println("<html>");
//			out.println("<head>");
//			out.println("<title>Login Page</title>");
//			out.println("</head>");
//			out.println("<body>");
//			out.println("Your not authorized");
//			out.println("</body>");
//			out.println("</html>");
			
			((HttpServletResponse)response).sendRedirect("Invalid1.html");
			
//			try {
//			Thread.sleep(5000);
//			} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			
			
//			RequestDispatcher rd = request.getRequestDispatcher("login.html");
//			rd.forward(request, response);
			
			//response.sendRedirect("login.html");
			// out.println("<html>");
			// out.println("<head>");
			// out.println("<title>Login Page</title>");
			// out.println("</head>");
			// out.println("<body>");
			// out.println("Your not authorized");
			// out.println("</body>");
			// out.println("</html>");

		}
		
	}
}
