package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class dynamic
 */
@WebServlet("/dynamic")
public class dynamic extends GenericServlet {
	private int i = 0;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see GenericServlet#GenericServlet()
     */
    public dynamic() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
    
    //request will contain all the requirements of the client
    //response is what the server will send back to the user
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//int i=0;
		out.println("<html>");
		out.println("<head>");
		
		out.println("</head>");
		
		out.println("<body>");
		out.println("<p>");
		out.println("Sleeping tight.... "+(++i)+" "+new Date());
		out.println("</p>");
		out.println("</body>");
		out.println("</html>");
	}

}
