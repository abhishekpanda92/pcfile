package com.virtusa.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



public class ColorListOperations {

	private List<String> colourList = new ArrayList<>();

	public void addColours(String colour) {
		colourList.add(colour);
	}

	public void savetoFile() throws IOException {
		FileWriter fileWriter = new FileWriter(new File(
				"C:\\database\\colours.txt"), true);
		// fileWriter = new FileWriter(file, true);
		for (int i = 0; i < colourList.size(); i++) {
			fileWriter.write(colourList.get(i));// appends the string
															// to the file
			fileWriter.write(System.getProperty("line.separator"));
		}
		fileWriter.close();

	}
	
	public void readFromFile() throws IOException
	{
		FileReader fileReader = new FileReader(new File(
				"C:\\database\\colours.txt"));
		BufferedReader br = new BufferedReader(fileReader);
		
		String colour = br.readLine();
		
		while(colour != null)
		{
			System.out.println(colour);
			colour = br.readLine();
		}
		
		br.close();
	}
	
}
