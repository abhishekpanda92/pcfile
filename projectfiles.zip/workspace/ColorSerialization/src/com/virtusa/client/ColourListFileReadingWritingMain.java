package com.virtusa.client;

import java.io.IOException;

import com.virtusa.services.ColorListOperations;

public class ColourListFileReadingWritingMain {

	public static void main(String[] args)
	{
		ColorListOperations colorListOperations = new ColorListOperations();
		colorListOperations.addColours("BLUE");
		colorListOperations.addColours("RED");
		colorListOperations.addColours("GREEN");
		colorListOperations.addColours("YELLOW");
		
		try {
			colorListOperations.savetoFile();
			colorListOperations.readFromFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
